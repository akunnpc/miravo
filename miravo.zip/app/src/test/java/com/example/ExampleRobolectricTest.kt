package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.common.VideoConfig
import com.example.receiver.DisplayMode
import com.example.receiver.ReceiverCanvasState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Miravo", appName)
  }

  @Test
  fun `verify video config defaults`() {
    val config = VideoConfig.DEFAULT
    assertEquals(1280, config.width)
    assertEquals(720, config.height)
    assertEquals(60, config.fps)
    assertEquals(8_000_000, config.bitrateBps)
  }

  @Test
  fun `verify receiver canvas state defaults`() {
    val state = ReceiverCanvasState.DEFAULT
    assertEquals(1.0f, state.zoomScale, 0.001f)
    assertEquals(0.0f, state.panX, 0.001f)
    assertEquals(0.0f, state.panY, 0.001f)
    assertEquals(0.0f, state.rotationDeg, 0.001f)
    assertEquals(DisplayMode.FIT, state.displayMode)
    assertFalse(state.isCleanView)
  }
}

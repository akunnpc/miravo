package com.example.common

import java.io.Serializable

data class VideoConfig(
    val width: Int = 1280,
    val height: Int = 720,
    val fps: Int = 60,
    val bitrateBps: Int = 8_000_000
) : Serializable {

    val bitrateMbps: Float
        get() = bitrateBps / 1_000_000f

    val resolutionLabel: String
        get() = "${width}x${height}"

    companion object {
        val PRESET_720P_60FPS = VideoConfig(1280, 720, 60, 8_000_000)
        val PRESET_1080P_60FPS = VideoConfig(1920, 1080, 60, 12_000_000)
        val PRESET_720P_30FPS = VideoConfig(1280, 720, 30, 5_000_000)
        val PRESET_540P_60FPS = VideoConfig(960, 540, 60, 4_000_000)

        val DEFAULT = PRESET_720P_60FPS

        val AVAILABLE_RESOLUTIONS = listOf(
            Pair(1920, 1080) to "1080p Full HD (1920x1080)",
            Pair(1280, 720) to "720p HD (1280x720) [Rekomendasi]",
            Pair(960, 540) to "540p qHD (960x540) [Ultra Rendah Latensi]",
            Pair(854, 480) to "480p SD (854x480)"
        )

        val AVAILABLE_FPS = listOf(60, 30)

        val AVAILABLE_BITRATES_BPS = listOf(
            2_000_000 to "2 Mbps (Hemat Jaringan)",
            4_000_000 to "4 Mbps (Rendah)",
            6_000_000 to "6 Mbps (Sedang)",
            8_000_000 to "8 Mbps (Default / Seimbang)",
            12_000_000 to "12 Mbps (Tinggi / Jernih)",
            16_000_000 to "16 Mbps (Ultra HD / Khusus Wi-Fi 5GHz)"
        )
    }
}

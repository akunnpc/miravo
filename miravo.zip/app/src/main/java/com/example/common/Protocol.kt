package com.example.common

import java.net.InetAddress
import java.net.NetworkInterface
import java.util.Collections

object Protocol {
    const val DEFAULT_VIDEO_PORT = 5000
    const val DEFAULT_FEEDBACK_PORT = 5001
    const val DEFAULT_DISCOVERY_PORT = 5002
    const val DEFAULT_CONTROL_PORT = 5003

    // Discovery messages (supporting both Miravo and UltraCast for backward compatibility)
    const val MIRAVO_DISCOVER = "MIRAVO_DISCOVER"
    const val ULTRACAST_DISCOVER = "ULTRACAST_DISCOVER"
    const val REPLY_PREFIX_MIRAVO = "MIRAVO:"
    const val REPLY_PREFIX_ULTRACAST = "ULTRACAST:"

    /**
     * Resolves all broadcast addresses across active local network interfaces (Wi-Fi, Hotspot, Ethernet).
     */
    fun getBroadcastAddresses(): List<InetAddress> {
        val targets = ArrayList<InetAddress>()
        try {
            for (ni in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in ni.interfaceAddresses) {
                    ia.broadcast?.let { targets.add(it) }
                }
            }
        } catch (_: Exception) {}

        try {
            targets.add(InetAddress.getByName("255.255.255.255"))
        } catch (_: Exception) {}

        return targets.distinct()
    }

    /**
     * Finds the local IP address for display on the UI.
     */
    fun getLocalIpAddress(): String {
        try {
            for (ni in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in Collections.list(ni.inetAddresses)) {
                    if (!ia.isLoopbackAddress && ia is java.net.Inet4Address) {
                        return ia.hostAddress ?: ""
                    }
                }
            }
        } catch (_: Exception) {}
        return "127.0.0.1"
    }
}

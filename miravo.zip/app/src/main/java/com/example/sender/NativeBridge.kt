package com.example.sender

import java.nio.ByteBuffer

/**
 * JNI Bridge to Miravo native UDP sender (C++).
 * Transmits direct ByteBuffers without CPU copying, calculates Reed-Solomon FEC,
 * and tracks receiver feedback for instant IDR requests.
 */
object NativeBridge {
    init {
        System.loadLibrary("udpsender")
    }

    /**
     * Initializes UDP video sender socket and feedback receiver socket.
     */
    external fun init(
        host: String,
        videoPort: Int,
        feedbackPort: Int,
        bitrateInit: Int,
        bitrateMin: Int,
        bitrateMax: Int
    ): Long

    /**
     * Sends a NAL unit through UDP fragmentation + Reed-Solomon FEC.
     */
    external fun send(
        handle: Long,
        buffer: ByteBuffer,
        offset: Int,
        size: Int,
        isConfig: Boolean,
        isKeyFrame: Boolean,
        ptsUs: Long,
        frameId: Int
    )

    /**
     * Polls whether the receiver requested an IDR / Keyframe.
     */
    external fun pollKeyframeRequest(handle: Long): Boolean

    /**
     * Reads current target bitrate from native layer.
     */
    external fun pollTargetBitrate(handle: Long): Int

    /**
     * Sets manual target bitrate directly.
     */
    external fun setManualBitrate(handle: Long, bitrate: Int)

    /**
     * Closes sockets, joins feedback thread, and releases native memory.
     */
    external fun close(handle: Long)
}

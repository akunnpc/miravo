package com.example.sender

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.os.Build
import android.os.Bundle
import android.view.Surface
import java.nio.ByteBuffer

/**
 * Hardware H.264 video encoder configured for low-latency streaming:
 * - Surface input (VirtualDisplay directly renders to GPU surface, zero CPU copying)
 * - Direct ByteBuffer output to native UDP sender layer
 * - Caches SPS/PPS config and re-sends before each IDR keyframe for instant receiver sync
 */
class VideoEncoder(
    private val width: Int,
    private val height: Int,
    private val fps: Int,
    private val bitrate: Int,
    private val handle: Long
) {
    lateinit var inputSurface: Surface
        private set

    private lateinit var codec: MediaCodec
    private var frameId: Int = 0
    private var cachedConfig: ByteBuffer? = null

    fun start() {
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
            )
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1) // 1 second keyframe interval
            setInteger(
                MediaFormat.KEY_BITRATE_MODE,
                MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
            }
        }

        codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        codec.setCallback(object : MediaCodec.Callback() {
            override fun onOutputBufferAvailable(
                mc: MediaCodec, index: Int, info: MediaCodec.BufferInfo
            ) {
                val buf: ByteBuffer? = mc.getOutputBuffer(index)
                if (buf != null && info.size > 0) {
                    val isConfig = info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                    val isKey = info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0

                    if (isConfig) {
                        // Cache SPS/PPS in direct buffer to resend before IDRs
                        val copy = ByteBuffer.allocateDirect(info.size)
                        val src = buf.duplicate()
                        src.position(info.offset)
                        src.limit(info.offset + info.size)
                        copy.put(src)
                        copy.position(0)
                        cachedConfig = copy
                    } else if (isKey) {
                        cachedConfig?.let { cfg ->
                            cfg.position(0)
                            NativeBridge.send(
                                handle, cfg, 0, cfg.capacity(),
                                true, false, info.presentationTimeUs, frameId
                            )
                            frameId++
                        }
                    }

                    NativeBridge.send(
                        handle, buf, info.offset, info.size,
                        isConfig, isKey, info.presentationTimeUs, frameId
                    )
                    frameId++
                }
                mc.releaseOutputBuffer(index, false)
            }

            override fun onInputBufferAvailable(mc: MediaCodec, index: Int) {}
            override fun onError(mc: MediaCodec, e: MediaCodec.CodecException) {
                e.printStackTrace()
            }
            override fun onOutputFormatChanged(mc: MediaCodec, format: MediaFormat) {}
        })

        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        inputSurface = codec.createInputSurface()
        codec.start()
    }

    /**
     * Forces immediate generation of an IDR sync frame (e.g. upon receiver request).
     */
    fun requestKeyFrame() {
        try {
            val params = Bundle().apply {
                putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
            }
            codec.setParameters(params)
        } catch (_: Exception) {}
    }

    /**
     * Updates encoder bitrate dynamically if manually changed by user.
     */
    fun setBitrate(bps: Int) {
        try {
            val params = Bundle().apply {
                putInt(MediaCodec.PARAMETER_KEY_VIDEO_BITRATE, bps)
            }
            codec.setParameters(params)
        } catch (_: Exception) {}
    }

    fun stop() {
        try {
            codec.stop()
            codec.release()
        } catch (_: Exception) {}
        try {
            inputSurface.release()
        } catch (_: Exception) {}
    }
}

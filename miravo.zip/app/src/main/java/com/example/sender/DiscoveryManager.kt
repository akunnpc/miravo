package com.example.sender

import android.os.SystemClock
import com.example.common.Protocol
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.SocketTimeoutException

data class DiscoveredReceiver(
    val name: String,
    val ip: String,
    val lastSeenTimestamp: Long = System.currentTimeMillis()
)

class DiscoveryManager {

    private val _receivers = MutableStateFlow<List<DiscoveredReceiver>>(emptyList())
    val receivers: StateFlow<List<DiscoveredReceiver>> = _receivers.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    suspend fun discoverReceivers(timeoutMs: Long = 2500) = withContext(Dispatchers.IO) {
        _isSearching.value = true
        val foundMap = mutableMapOf<String, DiscoveredReceiver>()

        try {
            val sock = DatagramSocket()
            sock.broadcast = true
            sock.soTimeout = 300

            val targets = Protocol.getBroadcastAddresses()
            val msgMiravo = Protocol.MIRAVO_DISCOVER.toByteArray()
            val msgUltra = Protocol.ULTRACAST_DISCOVER.toByteArray()

            fun sendQueries() {
                for (target in targets) {
                    try {
                        sock.send(DatagramPacket(msgMiravo, msgMiravo.size, target, Protocol.DEFAULT_DISCOVERY_PORT))
                        sock.send(DatagramPacket(msgUltra, msgUltra.size, target, Protocol.DEFAULT_DISCOVERY_PORT))
                    } catch (_: Exception) {}
                }
            }

            sendQueries()

            val buf = ByteArray(256)
            val deadline = SystemClock.elapsedRealtime() + timeoutMs

            while (SystemClock.elapsedRealtime() < deadline) {
                try {
                    val pkt = DatagramPacket(buf, buf.size)
                    sock.receive(pkt)
                    val ip = pkt.address.hostAddress ?: continue
                    val text = String(pkt.data, 0, pkt.length).trim()

                    var name = "Receiver ($ip)"
                    if (text.startsWith(Protocol.REPLY_PREFIX_MIRAVO)) {
                        name = text.removePrefix(Protocol.REPLY_PREFIX_MIRAVO).ifBlank { name }
                    } else if (text.startsWith(Protocol.REPLY_PREFIX_ULTRACAST)) {
                        name = text.removePrefix(Protocol.REPLY_PREFIX_ULTRACAST).ifBlank { name }
                    }

                    foundMap[ip] = DiscoveredReceiver(name = name, ip = ip)
                    _receivers.value = foundMap.values.toList()
                } catch (_: SocketTimeoutException) {
                    sendQueries()
                } catch (_: Exception) {}
            }
            sock.close()
        } catch (_: Exception) {}

        _isSearching.value = false
    }

    fun addManualReceiver(ip: String) {
        val trimmed = ip.trim()
        if (trimmed.isNotBlank()) {
            val current = _receivers.value.toMutableList()
            if (current.none { it.ip == trimmed }) {
                current.add(0, DiscoveredReceiver(name = "Manual: $trimmed", ip = trimmed))
                _receivers.value = current
            }
        }
    }
}

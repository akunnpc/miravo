package com.example.sender

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import com.example.MainActivity
import com.example.common.Protocol
import com.example.common.VideoConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ScreenCaptureService : Service() {

    companion object {
        const val TAG = "MiravoSender"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val EXTRA_TARGET_HOST = "extra_target_host"
        const val EXTRA_VIDEO_CONFIG = "extra_video_config"

        const val ACTION_STOP = "com.example.sender.ACTION_STOP"

        private const val CHANNEL_ID = "miravo_screen_stream"
        private const val NOTIF_ID = 1001

        private const val POLL_MS = 50L
        private const val KF_THROTTLE_MS = 250L

        private val _isStreaming = MutableStateFlow(false)
        val isStreaming: StateFlow<Boolean> = _isStreaming.asStateFlow()

        private val _currentHost = MutableStateFlow("")
        val currentHost: StateFlow<String> = _currentHost.asStateFlow()

        private val _activeConfig = MutableStateFlow(VideoConfig.DEFAULT)
        val activeConfig: StateFlow<VideoConfig> = _activeConfig.asStateFlow()
    }

    private var targetHost: String = ""
    private var config: VideoConfig = VideoConfig.DEFAULT
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var encoder: VideoEncoder? = null
    private var nativeHandle: Long = 0L

    @Volatile
    private var running = false
    private var pollThread: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (intent.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            startAsForeground()
        } catch (e: Throwable) {
            Log.e(TAG, "startForeground error", e)
            stopSelf()
            return START_NOT_STICKY
        }

        targetHost = intent.getStringExtra(EXTRA_TARGET_HOST) ?: ""
        val cfgExtra = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getSerializableExtra(EXTRA_VIDEO_CONFIG, VideoConfig::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getSerializableExtra(EXTRA_VIDEO_CONFIG) as? VideoConfig
        }
        config = cfgExtra ?: VideoConfig.DEFAULT

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (resultCode != Activity.RESULT_OK || data == null || targetHost.isBlank()) {
            Log.e(TAG, "Invalid parameters for screen capture")
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            startPipeline(resultCode, data)
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to start pipeline", e)
            stopSelf()
            return START_NOT_STICKY
        }

        return START_STICKY
    }

    private fun startPipeline(resultCode: Int, data: Intent) {
        Log.i(TAG, "Starting Miravo Sender pipeline to $targetHost with config $config")

        // Initialize native UDP socket with user-configured manual bitrate
        nativeHandle = NativeBridge.init(
            targetHost,
            Protocol.DEFAULT_VIDEO_PORT,
            Protocol.DEFAULT_FEEDBACK_PORT,
            config.bitrateBps,
            config.bitrateBps / 2,
            config.bitrateBps * 2
        )

        if (nativeHandle == 0L) {
            Log.e(TAG, "NativeBridge.init failed")
            stopSelf()
            return
        }

        encoder = VideoEncoder(
            width = config.width,
            height = config.height,
            fps = config.fps,
            bitrate = config.bitrateBps,
            handle = nativeHandle
        ).also { it.start() }

        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, data)

        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)

        virtualDisplay = projection?.createVirtualDisplay(
            "MiravoDisplay",
            config.width,
            config.height,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC,
            encoder!!.inputSurface,
            null,
            null
        )

        running = true
        _isStreaming.value = true
        _currentHost.value = targetHost
        _activeConfig.value = config

        startFeedbackPoll()
    }

    /**
     * Polls receiver feedback for keyframe requests (IDR) to recover from packet loss.
     * Note: Adaptive Bitrate is strictly disabled per Miravo manual quality requirements;
     * the encoder bitrate remains fixed at the user's manual configuration.
     */
    private fun startFeedbackPoll() {
        pollThread = Thread {
            var lastKf = 0L
            while (running) {
                try {
                    val h = nativeHandle
                    if (h != 0L && NativeBridge.pollKeyframeRequest(h)) {
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastKf >= KF_THROTTLE_MS) {
                            lastKf = now
                            encoder?.requestKeyFrame()
                            Log.d(TAG, "Keyframe (IDR) requested by receiver feedback")
                        }
                    }
                    Thread.sleep(POLL_MS)
                } catch (_: InterruptedException) {
                    break
                } catch (e: Exception) {
                    Log.w(TAG, "Feedback poll exception: ${e.message}")
                }
            }
        }.also { it.start() }
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Miravo Screen Streaming",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notifikasi status penyiaran layar Miravo"
            }
            nm.createNotificationChannel(channel)
        }

        val openIntent = Intent(this, MainActivity::class.java)
        val pendingOpen = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingStop = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notifBuilder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        val notif = notifBuilder
            .setContentTitle("Miravo Sender Aktif")
            .setContentText("Mentransmisikan layar (${config.resolutionLabel}, ${config.fps} FPS, ${config.bitrateMbps} Mbps)")
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setContentIntent(pendingOpen)
            .addAction(
                Notification.Action.Builder(
                    android.R.drawable.ic_menu_close_clear_cancel,
                    "Hentikan",
                    pendingStop
                ).build()
            )
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIF_ID,
                notif,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "ScreenCaptureService destroyed, cleaning up")
        running = false
        _isStreaming.value = false
        _currentHost.value = ""

        pollThread?.interrupt()
        try {
            pollThread?.join(500)
        } catch (_: InterruptedException) {}
        pollThread = null

        virtualDisplay?.release()
        virtualDisplay = null

        encoder?.stop()
        encoder = null

        projection?.stop()
        projection = null

        if (nativeHandle != 0L) {
            NativeBridge.close(nativeHandle)
            nativeHandle = 0L
        }
    }
}

package com.example

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NetworkWifi
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.common.Protocol
import com.example.common.VideoConfig
import com.example.receiver.DiscoveryResponder
import com.example.receiver.ReceiverActivity
import com.example.sender.DiscoveredReceiver
import com.example.sender.DiscoveryManager
import com.example.sender.ScreenCaptureService
import com.example.ui.theme.MiravoAccent
import com.example.ui.theme.MiravoCyan
import com.example.ui.theme.MiravoDarkBg
import com.example.ui.theme.MiravoIndigo
import com.example.ui.theme.MiravoSuccess
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val discoveryManager = DiscoveryManager()
    private val responder = DiscoveryResponder()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Background responder allows other senders on local network to see this device
        responder.start()

        setContent {
            MyApplicationTheme {
                MiravoMainScreen(
                    discoveryManager = discoveryManager,
                    onStartCapture = { targetHost, config ->
                        targetHostForCapture = targetHost
                        targetConfigForCapture = config
                        requestScreenCapture()
                    },
                    onStopCapture = {
                        val stopIntent = Intent(this, ScreenCaptureService::class.java).apply {
                            action = ScreenCaptureService.ACTION_STOP
                        }
                        startService(stopIntent)
                    },
                    onOpenReceiver = {
                        startActivity(Intent(this, ReceiverActivity::class.java))
                    }
                )
            }
        }
    }

    private var targetHostForCapture: String = ""
    private var targetConfigForCapture: VideoConfig = VideoConfig.DEFAULT

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                    putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
                    putExtra(ScreenCaptureService.EXTRA_TARGET_HOST, targetHostForCapture)
                    putExtra(ScreenCaptureService.EXTRA_VIDEO_CONFIG, targetConfigForCapture)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(serviceIntent)
                } else {
                    startService(serviceIntent)
                }
                Toast.makeText(this, "Siaran layar Miravo dimulai ke $targetHostForCapture", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Izin perekaman layar dibatalkan", Toast.LENGTH_SHORT).show()
            }
        }

    private fun requestScreenCapture() {
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureLauncher.launch(mgr.createScreenCaptureIntent())
    }

    override fun onDestroy() {
        super.onDestroy()
        responder.stop()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MiravoMainScreen(
    discoveryManager: DiscoveryManager,
    onStartCapture: (String, VideoConfig) -> Unit,
    onStopCapture: () -> Unit,
    onOpenReceiver: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var selectedTab by remember { mutableIntStateOf(0) }

    val isStreaming by ScreenCaptureService.isStreaming.collectAsState()
    val currentHost by ScreenCaptureService.currentHost.collectAsState()
    val activeConfig by ScreenCaptureService.activeConfig.collectAsState()

    // Permission launcher for POST_NOTIFICATIONS on Android 13+
    val notifPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MiravoCyan.copy(alpha = 0.2f))
                                .border(1.dp, MiravoCyan, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Cast,
                                contentDescription = "Miravo Logo",
                                tint = MiravoCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "MIRAVO",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.2.sp
                                ),
                                color = MiravoCyan
                            )
                            Text(
                                text = "Low-Latency Screen Mirroring",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MiravoDarkBg
                )
            )
        },
        containerColor = MiravoDarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Tab Selection Row
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MiravoCyan,
                edgePadding = 16.dp,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = MiravoCyan,
                        height = 3.dp
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Cast, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Sender (Kirim)")
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Tv, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Receiver (Canvas)")
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Panduan & Info")
                        }
                    }
                )
            }

            when (selectedTab) {
                0 -> SenderScreenContent(
                    discoveryManager = discoveryManager,
                    isStreaming = isStreaming,
                    currentHost = currentHost,
                    activeConfig = activeConfig,
                    onStartCapture = onStartCapture,
                    onStopCapture = onStopCapture
                )
                1 -> ReceiverScreenContent(
                    onOpenReceiver = onOpenReceiver
                )
                2 -> InfoScreenContent()
            }
        }
    }
}

@Composable
fun SenderScreenContent(
    discoveryManager: DiscoveryManager,
    isStreaming: Boolean,
    currentHost: String,
    activeConfig: VideoConfig,
    onStartCapture: (String, VideoConfig) -> Unit,
    onStopCapture: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val receivers by discoveryManager.receivers.collectAsState()
    val isSearching by discoveryManager.isSearching.collectAsState()

    var manualIp by remember { mutableStateOf("") }
    var selectedResolution by remember { mutableStateOf(Pair(1280, 720)) }
    var selectedFps by remember { mutableIntStateOf(60) }
    var selectedBitrate by remember { mutableIntStateOf(8_000_000) }

    LaunchedEffect(Unit) {
        discoveryManager.discoverReceivers()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Active Streaming Banner if running
        if (isStreaming) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MiravoSuccess, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(CircleShape)
                                        .background(MiravoSuccess)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "SEDANG MENYIARKAN LAYAR",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MiravoSuccess
                                )
                            }
                            Button(
                                onClick = onStopCapture,
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("stop_streaming_button")
                            ) {
                                Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Hentikan", fontSize = 13.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Target Receiver: $currentHost",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Format: ${activeConfig.resolutionLabel} @ ${activeConfig.fps} FPS | Bitrate: ${activeConfig.bitrateMbps} Mbps",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Manual Video Quality Settings Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Settings, contentDescription = null, tint = MiravoCyan)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "Pengaturan Kualitas Manual",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MiravoCyan
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "ABR otomatis dinonaktifkan: bitrate dan resolusi tetap konsisten sesuai pilihan Anda.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(Modifier.height(14.dp))

                    // Resolusi Selector
                    Text("Resolusi:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        VideoConfig.AVAILABLE_RESOLUTIONS.forEach { (res, label) ->
                            val isSelected = selectedResolution == res
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) MiravoCyan.copy(alpha = 0.15f) else Color.Transparent)
                                    .border(
                                        1.dp,
                                        if (isSelected) MiravoCyan else MaterialTheme.colorScheme.surfaceVariant,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { selectedResolution = res }
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = MiravoCyan, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(8.dp))
                                }
                                Text(label, style = MaterialTheme.typography.bodyMedium, color = if (isSelected) MiravoCyan else MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    // FPS & Bitrate Row
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        // FPS Column
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Frame Rate:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                VideoConfig.AVAILABLE_FPS.forEach { fps ->
                                    val isSelected = selectedFps == fps
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isSelected) MiravoIndigo else MaterialTheme.colorScheme.surfaceVariant)
                                            .clickable { selectedFps = fps }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("$fps FPS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }
                                }
                            }
                        }

                        // Bitrate Quick Options
                        Column(modifier = Modifier.weight(1.5f)) {
                            Text("Bitrate Target:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(4_000_000, 8_000_000, 12_000_000).forEach { br ->
                                    val isSelected = selectedBitrate == br
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isSelected) MiravoCyan else MaterialTheme.colorScheme.surfaceVariant)
                                            .clickable { selectedBitrate = br }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            "${br / 1_000_000}M",
                                            color = if (isSelected) Color.Black else Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Discovered Receivers Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Receiver Ditemukan",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    if (isSearching) {
                        Spacer(Modifier.width(8.dp))
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = MiravoCyan, strokeWidth = 2.dp)
                    }
                }
                IconButton(onClick = { coroutineScope.launch { discoveryManager.discoverReceivers() } }) {
                    Icon(Icons.Default.Refresh, contentDescription = "Pindai Ulang", tint = MiravoCyan)
                }
            }
        }

        if (receivers.isEmpty() && !isSearching) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Belum ada receiver ditemukan di jaringan lokal.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "Pastikan HP Receiver membuka Miravo dan terhubung ke Wi-Fi / Hotspot yang sama, atau gunakan input IP manual di bawah.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(receivers) { receiver ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = receiver.name,
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = "IP: ${receiver.ip}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MiravoCyan
                            )
                        }
                        Button(
                            onClick = {
                                val cfg = VideoConfig(
                                    width = selectedResolution.first,
                                    height = selectedResolution.second,
                                    fps = selectedFps,
                                    bitrateBps = selectedBitrate
                                )
                                onStartCapture(receiver.ip, cfg)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MiravoCyan),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("connect_receiver_${receiver.ip.replace(".", "_")}")
                        ) {
                            Text("Hubungkan", color = Color(0xFF03222B), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Manual IP Connection Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Koneksi Manual via IP / Hotspot",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Berguna saat salah satu HP menjadi Hotspot portabel atau broadcast terisolasi.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = manualIp,
                            onValueChange = { manualIp = it },
                            placeholder = { Text("Contoh: 192.168.43.1") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("manual_ip_input"),
                            shape = RoundedCornerShape(8.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MiravoCyan,
                                unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        )
                        Button(
                            onClick = {
                                val trimmed = manualIp.trim()
                                if (trimmed.isNotBlank()) {
                                    val cfg = VideoConfig(
                                        width = selectedResolution.first,
                                        height = selectedResolution.second,
                                        fps = selectedFps,
                                        bitrateBps = selectedBitrate
                                    )
                                    discoveryManager.addManualReceiver(trimmed)
                                    onStartCapture(trimmed, cfg)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MiravoIndigo),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("manual_connect_button")
                        ) {
                            Text("Kirim", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReceiverScreenContent(
    onOpenReceiver: () -> Unit
) {
    val localIp = remember { Protocol.getLocalIpAddress() }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Quick Launch Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MiravoCyan.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Tv, contentDescription = null, tint = MiravoCyan, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Receiver Canvas Aktif",
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                            Text(
                                text = "Siap menerima streaming video dari Miravo Sender",
                                style = MaterialTheme.typography.bodySmall,
                                color = MiravoCyan
                            )
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text(
                        text = "IP Perangkat Ini: $localIp",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = Color.White
                    )
                    Text(
                        text = "Port Video: ${Protocol.DEFAULT_VIDEO_PORT} (UDP) | Feedback: ${Protocol.DEFAULT_FEEDBACK_PORT}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(20.dp))
                    Button(
                        onClick = onOpenReceiver,
                        colors = ButtonDefaults.buttonColors(containerColor = MiravoCyan),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("open_receiver_canvas_button")
                    ) {
                        Icon(Icons.Default.Tv, contentDescription = null, tint = Color(0xFF03222B))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "Buka Layar Receiver (Canvas Mode)",
                            color = Color(0xFF03222B),
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }

        // Canvas Features Highlight Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Fitur Fleksibel Receiver Canvas:",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MiravoAccent
                    )
                    Spacer(Modifier.height(12.dp))
                    FeatureBullet("Pinch-to-Zoom 2 Jari:", "Perbesar & perkecil video secara bebas atau gunakan slider zoom.")
                    FeatureBullet("Geser / Drag 1 Jari:", "Pindahkan posisi video ke area layar manapun yang diinginkan.")
                    FeatureBullet("Rotasi Manual 90°:", "Putar orientasi video (+90°, -90°, 0°) tanpa putus koneksi streaming.")
                    FeatureBullet("Mode Tampilan:", "Pilihan Fit (utuh), Fill (penuh), 1:1 Asli, dan Custom.")
                    FeatureBullet("Mode Clean View:", "Sembunyikan semua kontrol dengan 1 sentuhan untuk live streaming jernih.")
                    FeatureBullet("Zero CPU Copy:", "Semua transformasi diproses pada GPU RenderThread tanpa beban CPU atau decoding ulang.")
                }
            }
        }
    }
}

@Composable
fun InfoScreenContent() {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Arsitektur Miravo",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MiravoCyan
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Miravo dikembangkan dari basis open-source UltraCast dengan pipeline ultra-low-latency:\n\n" +
                                "• Pengambilan layar via Android MediaProjection + VirtualDisplay ke Surface hardware.\n" +
                                "• Hardware MediaCodec H.264 (CBR & low-latency mode).\n" +
                                "• Transport UDP berkinerja tinggi dalam C++ dengan Reed-Solomon Erasure Coding (FEC).\n" +
                                "• Deteksi kemacetan berbasis delay (GCC style) dan pemulihan frame instan via IDR request.\n" +
                                "• Mode Kualitas Manual: Bitrate tidak diturunkan secara diam-diam oleh ABR.\n" +
                                "• Receiver Canvas: Transformasi tampilan (Zoom, Drag, Rotasi) dilakukan di lapisan rendering GPU TextureView.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 20.sp
                    )
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Lisensi & Atribusi Open-Source",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MiravoAccent
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Aplikasi ini dibangun dengan memodifikasi dan mengembangkan proyek UltraCast oleh Joel Pasapera.\n\n" +
                                "Lisensi: Apache License 2.0\n" +
                                "Hak cipta dilindungi dan atribusi dipertahankan sepenuhnya.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun FeatureBullet(title: String, desc: String) {
    Row(modifier = Modifier.padding(vertical = 4.dp)) {
        Text("• ", color = MiravoCyan, fontWeight = FontWeight.Bold)
        Column {
            Text(title, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = Color.White)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

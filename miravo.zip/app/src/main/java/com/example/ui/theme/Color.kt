package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MiravoCyan = Color(0xFF00E5FF)
val MiravoIndigo = Color(0xFF7C4DFF)
val MiravoAccent = Color(0xFF64FFDA)

val MiravoDarkBg = Color(0xFF0B132B)
val MiravoCardBg = Color(0xFF141E38)
val MiravoSurfaceVariant = Color(0xFF1F2B4D)

val MiravoTextPrimary = Color(0xFFF1F5F9)
val MiravoTextSecondary = Color(0xFF94A3B8)
val MiravoSuccess = Color(0xFF10B981)
val MiravoWarning = Color(0xFFF59E0B)
val MiravoError = Color(0xFFEF4444)

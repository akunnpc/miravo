package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = MiravoCyan,
    onPrimary = Color(0xFF03222B),
    primaryContainer = Color(0xFF004D59),
    onPrimaryContainer = Color(0xFF9CF4FF),

    secondary = MiravoIndigo,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF371D78),
    onSecondaryContainer = Color(0xFFE4D9FF),

    tertiary = MiravoAccent,
    onTertiary = Color(0xFF00382E),

    background = MiravoDarkBg,
    onBackground = MiravoTextPrimary,

    surface = MiravoCardBg,
    onSurface = MiravoTextPrimary,

    surfaceVariant = MiravoSurfaceVariant,
    onSurfaceVariant = MiravoTextSecondary,

    error = MiravoError,
    onError = Color.White
)

private val LightColorScheme = darkColorScheme(
    primary = MiravoCyan,
    onPrimary = Color(0xFF03222B),
    background = MiravoDarkBg,
    surface = MiravoCardBg,
    onBackground = MiravoTextPrimary,
    onSurface = MiravoTextPrimary
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use Miravo custom vibrant dark theme
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}

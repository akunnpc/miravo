package com.example.receiver

import android.os.Build
import android.util.Log
import com.example.common.Protocol
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress

class DiscoveryResponder {

    companion object {
        private const val TAG = "MiravoDiscoveryResp"
    }

    @Volatile
    private var isRunning = false
    private var workerThread: Thread? = null
    private var socket: DatagramSocket? = null

    fun start() {
        if (isRunning) return
        isRunning = true

        workerThread = Thread {
            val deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}".trim()
            val replyMiravo = "${Protocol.REPLY_PREFIX_MIRAVO}$deviceModel".toByteArray()
            val replyUltra = "${Protocol.REPLY_PREFIX_ULTRACAST}$deviceModel".toByteArray()

            while (isRunning) {
                try {
                    val sock = DatagramSocket(null).apply {
                        reuseAddress = true
                        bind(InetSocketAddress(Protocol.DEFAULT_DISCOVERY_PORT))
                    }
                    socket = sock
                    val buf = ByteArray(128)

                    while (isRunning) {
                        val packet = DatagramPacket(buf, buf.size)
                        sock.receive(packet)
                        val msg = String(packet.data, 0, packet.length).trim()

                        if (msg.startsWith(Protocol.MIRAVO_DISCOVER)) {
                            sock.send(DatagramPacket(replyMiravo, replyMiravo.size, packet.address, packet.port))
                        } else if (msg.startsWith(Protocol.ULTRACAST_DISCOVER)) {
                            sock.send(DatagramPacket(replyUltra, replyUltra.size, packet.address, packet.port))
                        }
                    }
                } catch (e: Exception) {
                    try {
                        socket?.close()
                    } catch (_: Exception) {}
                    if (!isRunning) break
                    try {
                        Thread.sleep(1000)
                    } catch (_: InterruptedException) {
                        break
                    }
                }
            }
            Log.d(TAG, "DiscoveryResponder thread stopped")
        }.also { it.start() }
    }

    fun stop() {
        isRunning = false
        try {
            socket?.close()
        } catch (_: Exception) {}
        socket = null

        workerThread?.interrupt()
        try {
            workerThread?.join(500)
        } catch (_: InterruptedException) {}
        workerThread = null
    }
}

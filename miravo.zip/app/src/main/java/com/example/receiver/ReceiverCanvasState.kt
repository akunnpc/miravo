package com.example.receiver

enum class DisplayMode {
    FIT,
    FILL,
    ORIGINAL,
    CUSTOM
}

data class ReceiverCanvasState(
    val zoomScale: Float = 1.0f,
    val panX: Float = 0.0f,
    val panY: Float = 0.0f,
    val rotationDeg: Float = 0.0f,
    val displayMode: DisplayMode = DisplayMode.FIT,
    val isCleanView: Boolean = false,
    val showDiagnostics: Boolean = true
) {
    companion object {
        const val MIN_ZOOM = 0.25f
        const val MAX_ZOOM = 5.00f
        const val ZOOM_STEP = 0.20f

        val DEFAULT = ReceiverCanvasState()
    }
}

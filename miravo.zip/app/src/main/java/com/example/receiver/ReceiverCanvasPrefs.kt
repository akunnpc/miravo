package com.example.receiver

import android.content.Context
import android.content.SharedPreferences

class ReceiverCanvasPrefs(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "miravo_receiver_canvas_prefs"
        private const val KEY_ZOOM = "pref_zoom_scale"
        private const val KEY_PAN_X = "pref_pan_x"
        private const val KEY_PAN_Y = "pref_pan_y"
        private const val KEY_ROTATION = "pref_rotation_deg"
        private const val KEY_DISPLAY_MODE = "pref_display_mode"
        private const val KEY_SHOW_DIAG = "pref_show_diag"
    }

    fun saveState(state: ReceiverCanvasState) {
        prefs.edit().apply {
            putFloat(KEY_ZOOM, state.zoomScale)
            putFloat(KEY_PAN_X, state.panX)
            putFloat(KEY_PAN_Y, state.panY)
            putFloat(KEY_ROTATION, state.rotationDeg)
            putString(KEY_DISPLAY_MODE, state.displayMode.name)
            putBoolean(KEY_SHOW_DIAG, state.showDiagnostics)
            apply()
        }
    }

    fun loadState(): ReceiverCanvasState {
        val zoom = prefs.getFloat(KEY_ZOOM, 1.0f)
        val panX = prefs.getFloat(KEY_PAN_X, 0.0f)
        val panY = prefs.getFloat(KEY_PAN_Y, 0.0f)
        val rotation = prefs.getFloat(KEY_ROTATION, 0.0f)
        val modeStr = prefs.getString(KEY_DISPLAY_MODE, DisplayMode.FIT.name)
        val mode = try {
            DisplayMode.valueOf(modeStr ?: DisplayMode.FIT.name)
        } catch (_: Exception) {
            DisplayMode.FIT
        }
        val showDiag = prefs.getBoolean(KEY_SHOW_DIAG, true)

        return ReceiverCanvasState(
            zoomScale = zoom,
            panX = panX,
            panY = panY,
            rotationDeg = rotation,
            displayMode = mode,
            isCleanView = false, // Clean view always defaults to false on startup so user sees controls
            showDiagnostics = showDiag
        )
    }

    fun clearState() {
        prefs.edit().clear().apply()
    }
}

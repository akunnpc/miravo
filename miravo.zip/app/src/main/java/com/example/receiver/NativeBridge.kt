package com.example.receiver

import java.nio.ByteBuffer

/**
 * JNI Bridge to Miravo native UDP receiver (C++).
 * Manages UDP frame reassembly, Reed-Solomon erasure decoding, delay-based congestion sensing,
 * and transmission of loss feedback & keyframe requests.
 */
object NativeBridge {
    init {
        System.loadLibrary("udpreceiver")
    }

    /**
     * Binds UDP video socket at [port] and feedback transmission socket toward sender at [feedbackPort].
     * Returns native handle pointer.
     */
    external fun init(port: Int, feedbackPort: Int): Long

    /**
     * Returns Direct ByteBuffer mapped to the native reassembly buffer.
     */
    external fun getBuffer(handle: Long): ByteBuffer

    /**
     * Blocks until a full video frame is completed/reconstructed by FEC.
     * Returns byte size of frame, or negative on shutdown.
     */
    external fun receiveFrame(handle: Long): Int

    /**
     * Flags of last received frame (bit0=config, bit1=keyframe).
     */
    external fun getFlags(handle: Long): Int

    /**
     * Presentation timestamp in microseconds of last received frame.
     */
    external fun getPts(handle: Long): Long

    /**
     * Status of SIMD acceleration for FEC:
     * 1 = NEON active (ARMv8 AArch64)
     * 0 = Scalable fallback (auto-test mismatch)
     * -1 = Non-NEON ABI (32-bit / x86)
     */
    external fun fecSimd(): Int

    /**
     * Signals native receiver loop to unblock and terminate.
     */
    external fun stop(handle: Long)

    /**
     * Closes socket and frees native memory.
     */
    external fun close(handle: Long)
}

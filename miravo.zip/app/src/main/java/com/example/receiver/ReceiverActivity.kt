package com.example.receiver

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.Surface
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import com.example.common.Protocol
import java.nio.ByteBuffer

class ReceiverActivity : Activity() {

    private lateinit var canvasView: ReceiverCanvasView
    private lateinit var overlayContainer: FrameLayout
    private lateinit var controlsPanel: LinearLayout
    private lateinit var statsText: TextView
    private lateinit var cleanViewHint: TextView

    private lateinit var canvasPrefs: ReceiverCanvasPrefs
    private val discoveryResponder = DiscoveryResponder()

    private var nativeHandle: Long = 0L
    private var decoder: VideoDecoder? = null
    @Volatile private var isRunning = false
    private var recvThread: Thread? = null

    // Telemetry
    private var frameCount = 0L
    private var totalBytes = 0L
    private var lastFpsTime = 0L
    private var framesThisSec = 0
    private var currentFps = 0
    private var currentKbps = 0
    private var bytesThisSec = 0L
    private var minFrameSize = Int.MAX_VALUE
    private var maxFrameSize = 0
    private var maxIdrSize = 0
    private var firstIdr = "—"
    private var spsBytes: ByteArray? = null
    private var ppsBytes: ByteArray? = null
    private var gotIdr = false
    private var preFeedDropped = 0
    private val nalCounts = IntArray(32)

    private val uiHandler = Handler(Looper.getMainLooper())
    private val statsRunnable = object : Runnable {
        override fun run() {
            updateStatsUI()
            uiHandler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Keep screen on during live streaming receiver mode
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemBars()

        canvasPrefs = ReceiverCanvasPrefs(this)
        val savedState = canvasPrefs.loadState()

        val root = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(android.graphics.Color.BLACK)
        }

        canvasView = ReceiverCanvasView(
            context = this,
            onSurfaceReady = { surface -> startReceiving(surface) },
            onSurfaceDestroyed = { stopReceiving() },
            onSingleTap = { toggleCleanView() }
        ).apply {
            setState(savedState)
        }
        root.addView(canvasView)

        buildOverlayUI(root)
        setContentView(root)

        discoveryResponder.start()
        uiHandler.post(statsRunnable)
    }

    private fun buildOverlayUI(root: FrameLayout) {
        overlayContainer = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }

        // Diagnostics Overlay (Top Left)
        statsText = TextView(this).apply {
            textSize = 12f
            setTextColor(0xFF00FFCC.toInt())
            setBackgroundColor(0xCC070B19.toInt())
            setPadding(24, 20, 24, 20)
            text = "Menunggu stream Miravo di port ${Protocol.DEFAULT_VIDEO_PORT}…"
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START
            ).apply {
                topMargin = 32
                marginStart = 32
            }
        }
        overlayContainer.addView(statsText)

        // Top Action Bar (Clean View toggle, Diagnostics toggle, Exit)
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(0xCC070B19.toInt())
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END
            ).apply {
                topMargin = 32
                marginEnd = 32
            }
        }

        val btnCleanView = Button(this).apply {
            text = "Clean View 🗖"
            textSize = 13f
            setOnClickListener { toggleCleanView() }
        }
        val btnToggleDiag = Button(this).apply {
            text = "Stats ℹ"
            textSize = 13f
            setOnClickListener {
                val current = canvasView.canvasState
                val newDiag = !current.showDiagnostics
                canvasView.setState(current.copy(showDiagnostics = newDiag))
                statsText.visibility = if (newDiag) View.VISIBLE else View.GONE
            }
        }
        val btnExit = Button(this).apply {
            text = "✕ Tutup"
            textSize = 13f
            setOnClickListener { finish() }
        }

        topBar.addView(btnCleanView)
        topBar.addView(btnToggleDiag)
        topBar.addView(btnExit)
        overlayContainer.addView(topBar)

        // Bottom Controls Dock (Canvas controls)
        controlsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xDD0D152D.toInt())
            setPadding(24, 16, 24, 20)
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        }

        // Row 1: Display Modes (Fit, Fill, 1:1, Custom)
        val modeScroll = HorizontalScrollView(this)
        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        val btnFit = Button(this).apply {
            text = "Fit (Utuh)"
            setOnClickListener {
                canvasView.setDisplayMode(DisplayMode.FIT)
                updateModeHighlight()
            }
        }
        val btnFill = Button(this).apply {
            text = "Fill (Layar Penuh)"
            setOnClickListener {
                canvasView.setDisplayMode(DisplayMode.FILL)
                updateModeHighlight()
            }
        }
        val btnOrig = Button(this).apply {
            text = "1:1 (Asli)"
            setOnClickListener {
                canvasView.setDisplayMode(DisplayMode.ORIGINAL)
                updateModeHighlight()
            }
        }
        val btnCustom = Button(this).apply {
            text = "Custom"
            setOnClickListener {
                canvasView.setDisplayMode(DisplayMode.CUSTOM)
                updateModeHighlight()
            }
        }

        modeRow.addView(btnFit)
        modeRow.addView(btnFill)
        modeRow.addView(btnOrig)
        modeRow.addView(btnCustom)
        modeScroll.addView(modeRow)
        controlsPanel.addView(modeScroll)

        // Row 2: Zoom Controls & Slider
        val zoomRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 10, 0, 10)
        }

        val zoomLabel = TextView(this).apply {
            text = "Zoom:"
            setTextColor(0xFFE0E0E0.toInt())
            textSize = 13f
            setPadding(0, 0, 16, 0)
        }
        val btnZoomMinus = Button(this).apply {
            text = "−"
            setOnClickListener {
                canvasView.zoomOut()
                updateModeHighlight()
            }
        }
        val zoomBar = SeekBar(this).apply {
            max = 100
            progress = ((canvasView.canvasState.zoomScale - ReceiverCanvasState.MIN_ZOOM) /
                    (ReceiverCanvasState.MAX_ZOOM - ReceiverCanvasState.MIN_ZOOM) * 100).toInt()
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val zoom = ReceiverCanvasState.MIN_ZOOM +
                                (progress / 100f) * (ReceiverCanvasState.MAX_ZOOM - ReceiverCanvasState.MIN_ZOOM)
                        canvasView.setZoom(zoom)
                        updateModeHighlight()
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        val btnZoomPlus = Button(this).apply {
            text = "+"
            setOnClickListener {
                canvasView.zoomIn()
                updateModeHighlight()
            }
        }
        val btnResetZoom = Button(this).apply {
            text = "Reset Zoom"
            setOnClickListener {
                canvasView.resetZoom()
                zoomBar.progress = 16
                updateModeHighlight()
            }
        }

        zoomRow.addView(zoomLabel)
        zoomRow.addView(btnZoomMinus)
        zoomRow.addView(zoomBar)
        zoomRow.addView(btnZoomPlus)
        zoomRow.addView(btnResetZoom)
        controlsPanel.addView(zoomRow)

        // Row 3: Rotation & Position & Reset All
        val toolScroll = HorizontalScrollView(this)
        val toolRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 8, 0, 0)
        }

        val btnRotCcw = Button(this).apply {
            text = "⟲ -90°"
            setOnClickListener { canvasView.rotateCcw(); updateModeHighlight() }
        }
        val btnRot0 = Button(this).apply {
            text = "0° Normal"
            setOnClickListener { canvasView.resetRotation(); updateModeHighlight() }
        }
        val btnRotCw = Button(this).apply {
            text = "⟳ +90°"
            setOnClickListener { canvasView.rotateCw(); updateModeHighlight() }
        }
        val btnResetPos = Button(this).apply {
            text = "✛ Reset Posisi"
            setOnClickListener { canvasView.resetPosition(); updateModeHighlight() }
        }
        val btnResetAll = Button(this).apply {
            text = "↺ Reset Semua"
            setOnClickListener {
                canvasView.resetAll()
                zoomBar.progress = 16
                updateModeHighlight()
            }
        }

        toolRow.addView(btnRotCcw)
        toolRow.addView(btnRot0)
        toolRow.addView(btnRotCw)
        toolRow.addView(btnResetPos)
        toolRow.addView(btnResetAll)
        toolScroll.addView(toolRow)
        controlsPanel.addView(toolScroll)

        overlayContainer.addView(controlsPanel)

        // Clean View Hint banner (briefly shows when entering clean view)
        cleanViewHint = TextView(this).apply {
            text = "Mode Clean View Aktif\nKetuk layar untuk menampilkan kontrol"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0x99000000.toInt())
            setPadding(32, 24, 32, 24)
            gravity = Gravity.CENTER
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        }
        overlayContainer.addView(cleanViewHint)

        root.addView(overlayContainer)
    }

    private fun updateModeHighlight() {
        // Keeps canvas state saved in preferences
        canvasPrefs.saveState(canvasView.canvasState)
    }

    private fun toggleCleanView() {
        val current = canvasView.canvasState
        val isClean = !current.isCleanView
        canvasView.setState(current.copy(isCleanView = isClean))

        if (isClean) {
            controlsPanel.visibility = View.GONE
            statsText.visibility = View.GONE
            cleanViewHint.visibility = View.VISIBLE
            uiHandler.postDelayed({ cleanViewHint.visibility = View.GONE }, 2000)
            hideSystemBars()
        } else {
            cleanViewHint.visibility = View.GONE
            controlsPanel.visibility = View.VISIBLE
            statsText.visibility = if (current.showDiagnostics) View.VISIBLE else View.GONE
            hideSystemBars()
        }
    }

    private fun startReceiving(surface: Surface) {
        if (isRunning) return
        isRunning = true

        lastFpsTime = SystemClock.elapsedRealtime()
        framesThisSec = 0
        bytesThisSec = 0L

        decoder = VideoDecoder(1280, 720, surface)
        nativeHandle = NativeBridge.init(Protocol.DEFAULT_VIDEO_PORT, Protocol.DEFAULT_FEEDBACK_PORT)
        if (nativeHandle == 0L) {
            statsText.text = "Gagal mengikat port ${Protocol.DEFAULT_VIDEO_PORT}"
            return
        }

        val frameBuf: ByteBuffer = NativeBridge.getBuffer(nativeHandle)

        recvThread = Thread {
            while (isRunning) {
                val size = NativeBridge.receiveFrame(nativeHandle)
                if (size <= 0) continue

                frameCount++
                framesThisSec++
                bytesThisSec += size
                totalBytes += size

                if (size < minFrameSize) minFrameSize = size
                if (size > maxFrameSize) maxFrameSize = size

                val ptsUs = NativeBridge.getPts(nativeHandle)
                frameBuf.clear()
                frameBuf.limit(size)

                val nalType = if (size >= 5) (frameBuf.get(4).toInt() and 0x1F) else -1
                if (nalType in 0..31) nalCounts[nalType]++

                if (nalType == 5) {
                    if (size > maxIdrSize) maxIdrSize = size
                    if (firstIdr == "—") {
                        val n = minOf(12, size)
                        val sb = StringBuilder()
                        for (i in 0 until n) sb.append(String.format("%02X ", frameBuf.get(i)))
                        firstIdr = sb.toString().trim()
                    }
                }

                val dec = decoder ?: continue
                if (!dec.started) {
                    harvestCsd(frameBuf, size)
                    val sps = spsBytes
                    val pps = ppsBytes
                    if (sps != null && pps != null) {
                        dec.startWithConfig(sps, pps)
                    } else {
                        preFeedDropped++
                    }
                    continue
                }

                if (!gotIdr) {
                    if (nalType == 5) gotIdr = true
                    else {
                        preFeedDropped++
                        continue
                    }
                }

                if (nalType == 7 || nalType == 8) continue
                dec.feedFrame(frameBuf, size, ptsUs)

                // Update canvas with actual decoded dimensions if format changed
                if (dec.videoWidth > 0 && dec.videoHeight > 0) {
                    canvasView.setVideoDimensions(dec.videoWidth, dec.videoHeight)
                }
            }
        }.also { it.start() }
    }

    private fun harvestCsd(buf: ByteBuffer, size: Int) {
        if (spsBytes != null && ppsBytes != null) return
        val pos = buf.position()
        val arr = ByteArray(size)
        for (k in 0 until size) arr[k] = buf.get(pos + k)
        val sc = ArrayList<IntArray>()
        var i = 0
        while (i + 2 < size) {
            if (arr[i].toInt() == 0 && arr[i + 1].toInt() == 0) {
                if (i + 3 < size && arr[i + 2].toInt() == 0 && arr[i + 3].toInt() == 1) {
                    sc.add(intArrayOf(i, i + 4))
                    i += 4
                    continue
                } else if (arr[i + 2].toInt() == 1) {
                    sc.add(intArrayOf(i, i + 3))
                    i += 3
                    continue
                }
            }
            i++
        }
        for (idx in sc.indices) {
            val payloadOff = sc[idx][1]
            if (payloadOff >= size) continue
            val nalType = arr[payloadOff].toInt() and 0x1F
            val scOff = sc[idx][0]
            val nextOff = if (idx + 1 < sc.size) sc[idx + 1][0] else size
            if (nalType == 7 && spsBytes == null) spsBytes = arr.copyOfRange(scOff, nextOff)
            if (nalType == 8 && ppsBytes == null) ppsBytes = arr.copyOfRange(scOff, nextOff)
        }
    }

    private fun updateStatsUI() {
        val now = SystemClock.elapsedRealtime()
        val elapsed = now - lastFpsTime
        if (elapsed >= 1000) {
            currentFps = ((framesThisSec * 1000f) / elapsed).toInt()
            currentKbps = ((bytesThisSec * 8f * 1000f) / (elapsed * 1000f)).toInt()
            framesThisSec = 0
            bytesThisSec = 0L
            lastFpsTime = now
        }

        val dec = decoder
        val simdState = try {
            when (NativeBridge.fecSimd()) {
                1 -> "NEON Aktif (ARMv8)"
                0 -> "Escalar (Auto-test fallback)"
                else -> "Escalar"
            }
        } catch (_: Exception) {
            "—"
        }

        val st = canvasView.canvasState
        val sb = StringBuilder()
        sb.append("MIRAVO RECEIVER TELEMETRI\n")
        sb.append("FPS: $currentFps | Bitrate: $currentKbps kbps\n")
        sb.append("Resolusi Output: ${dec?.outputFormat ?: "Menunggu stream"}\n")
        sb.append("Total Frame: $frameCount (Decoded: ${dec?.decodedCount ?: 0})\n")
        sb.append("FEC SIMD: $simdState | Drop: ${dec?.inDropped ?: 0}\n")
        sb.append("Mode Canvas: ${st.displayMode.name} (Zoom: ${String.format("%.1fx", st.zoomScale)}, Rotasi: ${st.rotationDeg.toInt()}°)\n")
        sb.append("Decoder: ${dec?.codecName ?: "—"}")

        statsText.text = sb.toString()
    }

    private fun stopReceiving() {
        isRunning = false
        if (nativeHandle != 0L) NativeBridge.stop(nativeHandle)
        try { recvThread?.join(800) } catch (_: InterruptedException) {}
        recvThread = null
        decoder?.stop()
        decoder = null
        if (nativeHandle != 0L) {
            NativeBridge.close(nativeHandle)
            nativeHandle = 0L
        }
    }

    override fun onPause() {
        super.onPause()
        canvasPrefs.saveState(canvasView.canvasState)
    }

    override fun onDestroy() {
        super.onDestroy()
        uiHandler.removeCallbacks(statsRunnable)
        discoveryResponder.stop()
        stopReceiving()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        or View.SYSTEM_UI_FLAG_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                )
    }
}

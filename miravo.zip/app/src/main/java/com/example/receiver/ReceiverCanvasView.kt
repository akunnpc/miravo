package com.example.receiver

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.TextureView
import android.view.ViewGroup
import android.widget.FrameLayout
import kotlin.math.max
import kotlin.math.min

/**
 * Flexible Video Canvas container for Miravo Receiver.
 * Renders video through a hardware-accelerated [TextureView] and applies
 * real-time GPU transformations (Zoom, Pan, Rotation, Fit/Fill/Original/Custom)
 * with zero CPU copying and zero re-decoding.
 */
@SuppressLint("ClickableViewAccessibility")
class ReceiverCanvasView(
    context: Context,
    private val onSurfaceReady: (Surface) -> Unit,
    private val onSurfaceDestroyed: () -> Unit,
    private val onSingleTap: () -> Unit
) : FrameLayout(context), TextureView.SurfaceTextureListener {

    val textureView: TextureView = TextureView(context).apply {
        layoutParams = LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        isOpaque = false
    }

    private var surface: Surface? = null
    var canvasState: ReceiverCanvasState = ReceiverCanvasState.DEFAULT
        private set

    private var videoWidth: Int = 1280
    private var videoHeight: Int = 720

    private val scaleDetector: ScaleGestureDetector
    private val gestureDetector: GestureDetector

    init {
        // Dark background for canvas
        setBackgroundColor(android.graphics.Color.BLACK)
        addView(textureView)
        textureView.surfaceTextureListener = this

        scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val factor = detector.scaleFactor
                val newZoom = (canvasState.zoomScale * factor).coerceIn(
                    ReceiverCanvasState.MIN_ZOOM,
                    ReceiverCanvasState.MAX_ZOOM
                )
                updateState(canvasState.copy(zoomScale = newZoom, displayMode = DisplayMode.CUSTOM))
                return true
            }
        })

        gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
            override fun onScroll(
                e1: MotionEvent?,
                e2: MotionEvent,
                distanceX: Float,
                distanceY: Float
            ): Boolean {
                val newPanX = canvasState.panX - distanceX
                val newPanY = canvasState.panY - distanceY
                updateState(canvasState.copy(panX = newPanX, panY = newPanY, displayMode = DisplayMode.CUSTOM))
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                onSingleTap()
                return true
            }
        })

        setOnTouchListener { _, event ->
            val scaleHandled = scaleDetector.onTouchEvent(event)
            val gestureHandled = gestureDetector.onTouchEvent(event)
            scaleHandled || gestureHandled || true
        }
    }

    override fun onSurfaceTextureAvailable(surfaceTexture: SurfaceTexture, width: Int, height: Int) {
        val s = Surface(surfaceTexture)
        surface = s
        onSurfaceReady(s)
        applyTransform()
    }

    override fun onSurfaceTextureSizeChanged(surfaceTexture: SurfaceTexture, width: Int, height: Int) {
        applyTransform()
    }

    override fun onSurfaceTextureDestroyed(surfaceTexture: SurfaceTexture): Boolean {
        onSurfaceDestroyed()
        surface?.release()
        surface = null
        return true
    }

    override fun onSurfaceTextureUpdated(surfaceTexture: SurfaceTexture) {
        // Frame rendered onto TextureView
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        applyTransform()
    }

    fun setVideoDimensions(w: Int, h: Int) {
        if (w > 0 && h > 0 && (w != videoWidth || h != videoHeight)) {
            videoWidth = w
            videoHeight = h
            post { applyTransform() }
        }
    }

    fun setState(newState: ReceiverCanvasState) {
        canvasState = newState
        applyTransform()
    }

    private fun updateState(newState: ReceiverCanvasState) {
        canvasState = newState
        applyTransform()
    }

    fun zoomIn() {
        val newZoom = (canvasState.zoomScale + ReceiverCanvasState.ZOOM_STEP)
            .coerceAtMost(ReceiverCanvasState.MAX_ZOOM)
        updateState(canvasState.copy(zoomScale = newZoom, displayMode = DisplayMode.CUSTOM))
    }

    fun zoomOut() {
        val newZoom = (canvasState.zoomScale - ReceiverCanvasState.ZOOM_STEP)
            .coerceAtLeast(ReceiverCanvasState.MIN_ZOOM)
        updateState(canvasState.copy(zoomScale = newZoom, displayMode = DisplayMode.CUSTOM))
    }

    fun setZoom(zoom: Float) {
        val clamped = zoom.coerceIn(ReceiverCanvasState.MIN_ZOOM, ReceiverCanvasState.MAX_ZOOM)
        updateState(canvasState.copy(zoomScale = clamped, displayMode = DisplayMode.CUSTOM))
    }

    fun resetZoom() {
        updateState(canvasState.copy(zoomScale = 1.0f))
    }

    fun resetPosition() {
        updateState(canvasState.copy(panX = 0.0f, panY = 0.0f))
    }

    fun rotateCw() {
        val newRot = (canvasState.rotationDeg + 90f) % 360f
        updateState(canvasState.copy(rotationDeg = newRot, displayMode = DisplayMode.CUSTOM))
    }

    fun rotateCcw() {
        val newRot = (canvasState.rotationDeg - 90f + 360f) % 360f
        updateState(canvasState.copy(rotationDeg = newRot, displayMode = DisplayMode.CUSTOM))
    }

    fun resetRotation() {
        updateState(canvasState.copy(rotationDeg = 0.0f))
    }

    fun setDisplayMode(mode: DisplayMode) {
        when (mode) {
            DisplayMode.FIT -> {
                updateState(canvasState.copy(displayMode = DisplayMode.FIT, zoomScale = 1.0f, panX = 0f, panY = 0f))
            }
            DisplayMode.FILL -> {
                updateState(canvasState.copy(displayMode = DisplayMode.FILL, zoomScale = 1.0f, panX = 0f, panY = 0f))
            }
            DisplayMode.ORIGINAL -> {
                updateState(canvasState.copy(displayMode = DisplayMode.ORIGINAL, zoomScale = 1.0f, panX = 0f, panY = 0f))
            }
            DisplayMode.CUSTOM -> {
                updateState(canvasState.copy(displayMode = DisplayMode.CUSTOM))
            }
        }
    }

    fun resetAll() {
        updateState(
            canvasState.copy(
                zoomScale = 1.0f,
                panX = 0.0f,
                panY = 0.0f,
                rotationDeg = 0.0f,
                displayMode = DisplayMode.FIT
            )
        )
    }

    /**
     * Applies GPU-accelerated transformations to the TextureView.
     * Calculated based on view dimensions, video aspect ratio, display mode,
     * zoom factor, pan offset, and rotation.
     */
    private fun applyTransform() {
        val viewW = width.toFloat()
        val viewH = height.toFloat()
        if (viewW <= 0f || viewH <= 0f) return

        val isRotated90 = (canvasState.rotationDeg.toInt() % 180 != 0)
        val effectiveVideoW = if (isRotated90) videoHeight.toFloat() else videoWidth.toFloat()
        val effectiveVideoH = if (isRotated90) videoWidth.toFloat() else videoHeight.toFloat()

        val scaleXBase: Float
        val scaleYBase: Float

        when (canvasState.displayMode) {
            DisplayMode.FIT -> {
                val scale = min(viewW / effectiveVideoW, viewH / effectiveVideoH)
                val targetW = effectiveVideoW * scale
                val targetH = effectiveVideoH * scale
                scaleXBase = targetW / viewW
                scaleYBase = targetH / viewH
            }
            DisplayMode.FILL -> {
                val scale = max(viewW / effectiveVideoW, viewH / effectiveVideoH)
                val targetW = effectiveVideoW * scale
                val targetH = effectiveVideoH * scale
                scaleXBase = targetW / viewW
                scaleYBase = targetH / viewH
            }
            DisplayMode.ORIGINAL -> {
                scaleXBase = effectiveVideoW / viewW
                scaleYBase = effectiveVideoH / viewH
            }
            DisplayMode.CUSTOM -> {
                // In custom mode, base fit scale is multiplied by user zoom
                val scale = min(viewW / effectiveVideoW, viewH / effectiveVideoH)
                val targetW = effectiveVideoW * scale
                val targetH = effectiveVideoH * scale
                scaleXBase = targetW / viewW
                scaleYBase = targetH / viewH
            }
        }

        val finalScaleX = scaleXBase * canvasState.zoomScale
        val finalScaleY = scaleYBase * canvasState.zoomScale

        // Apply hardware transformation properties directly to the TextureView
        textureView.pivotX = viewW / 2f
        textureView.pivotY = viewH / 2f
        textureView.scaleX = finalScaleX
        textureView.scaleY = finalScaleY
        textureView.translationX = canvasState.panX
        textureView.translationY = canvasState.panY
        textureView.rotation = canvasState.rotationDeg
    }
}

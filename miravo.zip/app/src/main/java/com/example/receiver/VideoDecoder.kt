package com.example.receiver

import android.media.MediaCodec
import android.media.MediaFormat
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer

/**
 * Low-latency hardware H.264 video decoder rendering directly to a Surface.
 * Feeds output directly to GPU Surface (for TextureView), avoiding CPU bitmap copies.
 */
class VideoDecoder(
    private val width: Int,
    private val height: Int,
    private val surface: Surface
) {
    companion object {
        private const val TAG = "MiravoDecoder"
    }

    private lateinit var codec: MediaCodec
    private val info = MediaCodec.BufferInfo()

    @Volatile var started = false
    @Volatile var codecName = "—"
    @Volatile var csdInfo = "—"
    @Volatile var inQueued = 0
    @Volatile var inDropped = 0
    @Volatile var decodedCount = 0
    @Volatile var formatChangedCount = 0
    @Volatile var outputFormat = "—"
    @Volatile var videoWidth = width
    @Volatile var videoHeight = height
    @Volatile var lastError = "none"

    fun startWithConfig(sps: ByteArray, pps: ByteArray) {
        if (started) return
        try {
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                setByteBuffer("csd-0", ByteBuffer.wrap(sps))
                setByteBuffer("csd-1", ByteBuffer.wrap(pps))
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 1024 * 1024 * 2)
                setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
            }
            csdInfo = "SPS ${sps.size}B + PPS ${pps.size}B"

            codec = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            codecName = try { codec.name } catch (_: Exception) { "AVC" }
            codec.configure(format, surface, null, 0)
            codec.start()
            started = true
            Log.i(TAG, "Decoder started: $codecName with $csdInfo")
        } catch (e: Exception) {
            lastError = "configure: ${e.message}"
            Log.e(TAG, "Decoder start error", e)
        }
    }

    fun feedFrame(nal: ByteBuffer, size: Int, ptsUs: Long) {
        if (!started) return
        try {
            val inIndex = codec.dequeueInputBuffer(10_000)
            if (inIndex >= 0) {
                val inBuf = codec.getInputBuffer(inIndex)
                if (inBuf != null) {
                    inBuf.clear()
                    inBuf.put(nal)
                    codec.queueInputBuffer(inIndex, 0, size, ptsUs, 0)
                    inQueued++
                }
            } else {
                inDropped++
            }
            drainOutput()
        } catch (e: Exception) {
            lastError = "feed: ${e.message}"
        }
    }

    private fun drainOutput() {
        while (true) {
            val outIndex = codec.dequeueOutputBuffer(info, 0)
            when {
                outIndex >= 0 -> {
                    codec.releaseOutputBuffer(outIndex, true)
                    decodedCount++
                }
                outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    formatChangedCount++
                    try {
                        val f = codec.outputFormat
                        val w = f.getInteger(MediaFormat.KEY_WIDTH, -1)
                        val h = f.getInteger(MediaFormat.KEY_HEIGHT, -1)
                        if (w > 0 && h > 0) {
                            videoWidth = w
                            videoHeight = h
                            outputFormat = "${w}x${h}"
                        }
                    } catch (_: Exception) {}
                }
                else -> break
            }
        }
    }

    fun stop() {
        try {
            if (started) {
                codec.stop()
                codec.release()
                started = false
            }
        } catch (e: Exception) {
            Log.w(TAG, "Stop exception: ${e.message}")
        }
    }
}

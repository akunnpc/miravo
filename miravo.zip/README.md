# MIRAVO - Screen Mirroring Android-ke-Android Berlatensi Rendah dengan Fleksibel Receiver Canvas

Miravo adalah aplikasi screen mirroring berkinerja tinggi yang dirancang untuk transmisi layar real-time antar perangkat Android (seperti Infinix Note 30 ke Xiaomi Redmi 12C) melalui jaringan lokal (Wi-Fi / Hotspot).

Proyek ini dikembangkan dari basis open-source **UltraCast** (oleh Joel Pasapera, lisensi Apache 2.0) dengan penambahan identitas baru, penonaktifan degradasi kualitas otomatis (manual bitrate & resolution control), serta fitur utama **Receiver Video Canvas** yang fleksibel untuk kebutuhan live streaming dan monitoring.

---

## Fitur Utama

### A. Miravo Sender
- **Hardware H.264 Encoding**: Menggunakan Android `MediaCodec` AVC dengan mode CBR dan `KEY_LOW_LATENCY`.
- **Zero-Copy Surface Capture**: Menggunakan `MediaProjection` dan `VirtualDisplay` yang menggambar langsung ke encoder Surface tanpa beban CPU.
- **Transmisi UDP Berkinerja Tinggi**: Dibangun dengan C++ NDK, pengelompokan batch paket, dan pacing cerdas.
- **Perlindungan Paket FEC (Forward Error Correction)**: Reed-Solomon Erasure Coding di GF(2^8) dengan optimasi SIMD ARM NEON untuk memulihkan paket yang hilang tanpa menunggu retransmisi.
- **Kontrol Kualitas Manual Penuh**: Pengguna dapat memilih resolusi (1080p, 720p, 540p), frame rate (30 / 60 FPS), dan bitrate target (2 Mbps - 16 Mbps).
- **Non-Adaptive Bitrate**: Algoritma ABR otomatis yang sebelumnya menurunkan bitrate dinonaktifkan; kualitas video dipertahankan konsisten sesuai pilihan manual pengguna.
- **Pemulihan Cepat (IDR on Demand)**: Menerima umpan balik saluran balik untuk memicu I-Frame instan saat terjadi kehilangan paket parah.

### B. Miravo Receiver & Video Canvas
- **Hardware H.264 Decoding**: `MediaCodec` AVC mendekode frame langsung ke hardware `Surface` / `TextureView`.
- **Receiver Video Canvas Fleksibel**: Video tidak dipaksa fullscreen, melainkan dapat diatur layaknya objek canvas:
  - **Zoom In / Out**: Gestur 2-jari (pinch-to-zoom), tombol `+` dan `−`, slider zoom (0.25x – 5.0x), serta tombol Reset Zoom.
  - **Geser / Pan Posisi**: Gestur 1-jari (drag/pan) untuk memindahkan video ke area layar manapun, serta tombol Reset Position ke tengah.
  - **Rotasi Manual 90°**: Putar searah jarum jam (`+90°`), berlawanan jarum jam (`-90°`), dan kembali ke `0°` tanpa memutus koneksi streaming.
  - **Mode Tampilan**:
    - **Fit**: Menampilkan seluruh video utuh tanpa terpotong (letterbox).
    - **Fill**: Mengisi seluruh layar (mungkin crop sisi).
    - **1:1 (Original)**: Tampilan rasio resolusi asli.
    - **Custom**: Posisi, zoom, dan rotasi manual pengguna.
  - **Reset Kontrol**: Reset Zoom, Reset Posisi, Reset Rotasi, dan Reset All.
  - **Penyimpanan Layout**: Preferensi transformasi canvas disimpan otomatis di `SharedPreferences` sehingga tetap tersimpan saat membuka kembali aplikasi.
- **Mode Clean View**:
  - Tombol Clean View menyembunyikan semua kontrol tombol, dock, dan overlay diagnostik.
  - Layar menjadi bersih sempurna untuk ditangkap aplikasi live streaming, screen recorder, atau monitor eksternal.
  - Ketuk (single tap) di layar untuk memunculkan kembali kontrol secara halus.
- **Zero CPU Copying**: Seluruh transformasi (Zoom, Pan, Rotasi) dieksekusi di GPU RenderThread pada lapisan `TextureView`, tidak ada alokasi Bitmap per frame dan tidak ada decoding ulang.
- **Telemetri Real-Time**: Pemantauan FPS, bitrate aktual, resolusi output, drop counter, dan status SIMD NEON.

---

## Struktur Proyek

```
/
├── app/                      # Aplikasi Miravo terpadu (Sender + Receiver Canvas)
│   ├── src/main/cpp/         # Native C++ UDP transport, FEC, dan JNI bridge
│   │   ├── CMakeLists.txt
│   │   ├── fec.cpp / fec.h   # Reed-Solomon Erasure Coding (GF(2^8) + NEON SIMD)
│   │   ├── udp_sender.cpp    # UDP Sender dengan pacing & feedback loop
│   │   ├── udp_receiver.cpp  # UDP Receiver dengan delay-based congestion sensing
│   │   ├── packet.h          # Struktur header paket biner 26-byte
│   │   └── feedback.h        # Paket feedback saluran balik
│   ├── src/main/java/com/example/
│   │   ├── MainActivity.kt   # Hub utama Miravo (Mode Sender, Receiver, Panduan)
│   │   ├── common/           # Protokol port & konfigurasi video
│   │   ├── sender/           # ScreenCaptureService, VideoEncoder, NativeBridge
│   │   └── receiver/         # ReceiverActivity, ReceiverCanvasView, VideoDecoder
├── sender/                   # Modul / proyek Sender mandiri
├── receiver/                 # Modul / proyek Receiver mandiri
├── LICENSE                   # Lisensi Apache License 2.0
├── NOTICE                    # Pemberitahuan atribusi UltraCast
└── README.md                 # Dokumentasi ini
```

---

## Petunjuk Build & Instalasi

### Persyaratan:
- Android SDK (API 34+ / Target SDK 36, Min SDK 26)
- Android NDK `26.1.10909125` (atau NDK r25+)
- CMake `3.22.1`
- JDK 17 / 21

### Build APK Menggunakan Gradle:
```bash
# Build aplikasi utama Miravo
gradle :app:assembleDebug

# Atau build modul mandiri sender & receiver
gradle -p sender assembleDebug
gradle -p receiver assembleDebug
```

Hasil file APK akan berada di:
`app/build/outputs/apk/debug/app-debug.apk`

---

## Petunjuk Penggunaan (Infinix Note 30 & Xiaomi Redmi 12C)

1. **Koneksi Jaringan**:
   - Hubungkan kedua HP ke Wi-Fi yang sama, **atau**
   - Aktifkan Hotspot portabel di salah satu HP (misal Infinix Note 30) dan sambungkan HP lainnya (Xiaomi Redmi 12C) ke Hotspot tersebut.
2. **Di HP Receiver (misal Xiaomi Redmi 12C)**:
   - Buka aplikasi **Miravo**.
   - Pilih tab **Receiver (Canvas)** lalu tekan **Buka Layar Receiver (Canvas Mode)**.
   - Layar akan masuk ke mode landscape/immersive siap menerima video.
3. **Di HP Sender (misal Infinix Note 30)**:
   - Buka aplikasi **Miravo**.
   - Pada tab **Sender**, pilih kualitas manual (misal 720p @ 60 FPS, 8 Mbps).
   - Receiver akan terdeteksi otomatis pada daftar **Receiver Ditemukan**.
   - Tekan **Hubungkan**, lalu konfirmasi dialog izin rekam layar Android.
4. **Mengatur Canvas di Receiver**:
   - Gunakan gestur 2 jari untuk memperbesar/memperkecil video.
   - Gunakan gestur 1 jari untuk menggeser posisi video ke sudut/posisi streaming yang diinginkan.
   - Tekan tombol **Clean View** untuk menyembunyikan antarmuka tombol saat live streaming dimulai.

---

## Lisensi & Atribusi

Proyek ini dilisensikan di bawah **Apache License 2.0**.
Lihat berkas `LICENSE` dan `NOTICE` untuk rincian lengkap mengenai hak cipta dan atribusi UltraCast oleh Joel Pasapera.

# MirrorLive

Aplikasi Android Native (Kotlin + Jetpack Compose) untuk mirroring layar Android ke Android khusus untuk menonton dan live streaming, tanpa PC, tanpa root, tanpa RTMP/stream key, dan tanpa kontrol/touch.

## Peran Perangkat
- **HP 1 (HP Game)**: Perangkat yang layarnya di-mirror. Hanya memerlukan fitur **Wireless Debugging** (Proses debug nirkabel) aktif di Opsi Pengembang. Tidak perlu membuka aplikasi ini saat mirroring berlangsung.
- **HP 2 (HP Live)**: Perangkat yang menjalankan MirrorLive sebagai klien ADB, menampilkan video gameplay secara layar penuh (fullscreen immersive), lalu pengguna melakukan live streaming dari HP 2 menggunakan fitur screen share bawaan platform (TikTok Live, YouTube, dll).

## Cara Pakai

### Langkah 1: Siapkan HP 1 (HP Game)
1. Aktifkan **Opsi Pengembang** (ketuk Nomor Versi 7 kali di Pengaturan > Tentang Ponsel).
2. Di Opsi Pengembang, aktifkan **Proses debug nirkabel** (Wireless Debugging) dan izinkan jaringan Wi-Fi saat ini.
3. Pastikan HP 1 terhubung ke jaringan Wi-Fi atau hotspot yang sama dengan HP 2.

### Langkah 2: Pairing & Hubungkan dari HP 2 (HP Live)
1. Buka **MirrorLive** di HP 2, pilih kartu **HP 2 (HP Live)**.
2. **Pairing**:
   - **Metode Utama (Kode QR)**: HP 2 menampilkan kode QR format standar Android Studio (`WIFI:T:ADB;S:...;P:...;;`). Di HP 1, buka *Opsi Pengembang > Proses debug nirkabel > Sambungkan perangkat dengan kode QR* lalu arahkan kamera ke layar HP 2. Pairing terjadi otomatis via mDNS.
   - **Metode Cadangan (Kode 6 Digit)**: Pilih tab "Kode 6 Digit", masukkan IP HP 1, port pairing dari dialog HP 1, dan 6 digit kodenya.
3. **Hubungkan**:
   - Pilih HP 1 dari daftar perangkat yang ditemukan otomatis via mDNS (`_adb-tls-connect._tcp`), atau masukkan IP dan port Wireless Debugging HP 1 secara manual.
4. **Mulai Mirror**:
   - Tekan tombol **Mulai Mirror Layar**. Layar HP 1 akan tampil dalam mode fullscreen tanpa gangguan.
   - Ketuk layar kapan saja untuk memunculkan tombol kontrol mengambang (**Stop**, **Hubungkan Ulang**, **Pengaturan**).

## Atribusi & Lisensi
- **scrcpy-server** v4.0 (Genymobile) - Lisensi Apache-2.0 ([GitHub](https://github.com/Genymobile/scrcpy))
- **Kadb** & **Kadb-mDNS** v2.1.4 (flyfishxu) - Lisensi Apache-2.0 ([GitHub](https://github.com/flyfishxu/Kadb))
- **ZXing Core** - Lisensi Apache-2.0

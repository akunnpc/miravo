package com.mamang.mirrorlive.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SensorsOff
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mamang.mirrorlive.domain.model.ConnectionState
import com.mamang.mirrorlive.ui.theme.AccentCyan
import com.mamang.mirrorlive.ui.theme.ErrorRed
import com.mamang.mirrorlive.ui.theme.ErrorRedContainer
import com.mamang.mirrorlive.ui.theme.PrimaryBlue
import com.mamang.mirrorlive.ui.theme.SuccessGreen
import com.mamang.mirrorlive.ui.theme.SurfaceBorderDark
import com.mamang.mirrorlive.ui.theme.SurfaceDark
import com.mamang.mirrorlive.ui.theme.TextPrimary
import com.mamang.mirrorlive.ui.theme.TextSecondary
import com.mamang.mirrorlive.ui.theme.WarningAmber

@Composable
fun StatusCard(
    state: ConnectionState,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (title, description, iconTint, borderColor) = when (state) {
        is ConnectionState.Idle -> StatusUi("Belum Pairing", "Siapkan HP 1 lalu lakukan pairing sekali saja.", TextSecondary, SurfaceBorderDark)
        is ConnectionState.WaitingQrScan -> StatusUi("Menunggu Pindai QR", "Pindai kode QR dari layar Wireless Debugging HP 1.", AccentCyan, AccentCyan.copy(alpha = 0.5f))
        is ConnectionState.PairingInProgress -> StatusUi("Sedang Pairing...", "Menghubungkan otorisasi keamanan ADB ke HP 1.", AccentCyan, AccentCyan.copy(alpha = 0.5f))
        is ConnectionState.PairingSuccess -> StatusUi("Pairing Berhasil", "Kunci otorisasi tersimpan. HP 1 siap dihubungkan.", SuccessGreen, SuccessGreen.copy(alpha = 0.5f))
        is ConnectionState.SearchingDevice -> StatusUi("Mencari HP 1", state.message, PrimaryBlue, PrimaryBlue.copy(alpha = 0.5f))
        is ConnectionState.PreparingServer -> StatusUi("Menyiapkan Server", state.stepMessage, PrimaryBlue, PrimaryBlue.copy(alpha = 0.5f))
        is ConnectionState.Connected -> StatusUi("Terhubung ke ${state.deviceName}", "Alamat: ${state.host}:${state.port}. Siap memulai mirror.", SuccessGreen, SuccessGreen.copy(alpha = 0.5f))
        is ConnectionState.MirrorRunning -> StatusUi("Mirror Berjalan", "${state.width}x${state.height} • ${state.bitrateMbps} Mbps", SuccessGreen, SuccessGreen.copy(alpha = 0.5f))
        is ConnectionState.Disconnected -> StatusUi("Terputus", state.reason, WarningAmber, WarningAmber.copy(alpha = 0.5f))
        is ConnectionState.Error -> StatusUi("Error", state.error.message, ErrorRed, ErrorRed.copy(alpha = 0.5f))
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SurfaceDark)
            .border(1.dp, borderColor, RoundedCornerShape(16.dp))
            .padding(16.dp)
            .testTag("status_card")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(iconTint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                when (state) {
                    is ConnectionState.SearchingDevice,
                    is ConnectionState.PairingInProgress -> {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = iconTint,
                            strokeWidth = 2.dp
                        )
                    }
                    is ConnectionState.PreparingServer -> {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = iconTint,
                            strokeWidth = 2.dp
                        )
                    }
                    is ConnectionState.WaitingQrScan -> {
                        Icon(Icons.Default.QrCode, null, tint = iconTint, modifier = Modifier.size(20.dp))
                    }
                    is ConnectionState.PairingSuccess,
                    is ConnectionState.Connected -> {
                        Icon(Icons.Default.CheckCircle, null, tint = iconTint, modifier = Modifier.size(20.dp))
                    }
                    is ConnectionState.MirrorRunning -> {
                        Icon(Icons.Default.PlayCircle, null, tint = iconTint, modifier = Modifier.size(20.dp))
                    }
                    is ConnectionState.Disconnected -> {
                        Icon(Icons.Default.SensorsOff, null, tint = iconTint, modifier = Modifier.size(20.dp))
                    }
                    is ConnectionState.Error -> {
                        Icon(Icons.Default.Error, null, tint = iconTint, modifier = Modifier.size(20.dp))
                    }
                    else -> {
                        Icon(Icons.Default.Info, null, tint = iconTint, modifier = Modifier.size(20.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    lineHeight = 17.sp
                )
            }
        }

        // Progress bar for preparing server
        if (state is ConnectionState.PreparingServer && state.progressFraction != null) {
            Spacer(modifier = Modifier.height(10.dp))
            LinearProgressIndicator(
                progress = { state.progressFraction },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = PrimaryBlue,
                trackColor = SurfaceBorderDark
            )
        }

        // Recovery hint & retry button on Error
        if (state is ConnectionState.Error) {
            val hint = state.error.recoveryHint
            if (hint != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Solusi: $hint",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            FilledTonalButton(
                onClick = onRetry,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("status_retry_button"),
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = ErrorRedContainer,
                    contentColor = ErrorRed
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Coba Lagi", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

private data class StatusUi(
    val title: String,
    val description: String,
    val iconTint: Color,
    val borderColor: Color
)

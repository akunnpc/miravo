package com.mamang.mirrorlive.ui.mirror

import android.app.Application
import android.view.Surface
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mamang.mirrorlive.core.AppContainer
import com.mamang.mirrorlive.core.AppResult
import com.mamang.mirrorlive.core.Logger
import com.mamang.mirrorlive.data.stream.StreamSocket
import com.mamang.mirrorlive.domain.model.ConnectionState
import com.mamang.mirrorlive.domain.model.MirrorConfig
import com.mamang.mirrorlive.domain.model.MirrorError
import com.mamang.mirrorlive.media.VideoDecoder
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MirrorViewModel(application: Application) : AndroidViewModel(application) {

    private val container = AppContainer.getInstance(application)

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.PreparingServer("Menyiapkan server..."))
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _videoDimensions = MutableStateFlow(Pair(1280, 720))
    val videoDimensions: StateFlow<Pair<Int, Int>> = _videoDimensions.asStateFlow()

    private var activeStreamSocket: StreamSocket? = null
    private var videoDecoder: VideoDecoder? = null

    init {
        videoDecoder = VideoDecoder(
            onDimensionsChanged = { w, h ->
                _videoDimensions.value = Pair(w, h)
                val curr = _connectionState.value
                if (curr is ConnectionState.MirrorRunning) {
                    _connectionState.value = curr.copy(width = w, height = h)
                }
            },
            onError = { err ->
                Logger.e("VideoDecoder error", err)
                _connectionState.value = ConnectionState.Error(
                    MirrorError.DecoderFailed(err.localizedMessage ?: "Decoder hardware error")
                )
            }
        )
    }

    fun onSurfaceAvailable(surface: Surface) {
        Logger.i("Surface provided to MirrorViewModel")
        videoDecoder?.setSurface(surface)
    }

    fun startMirror(host: String, port: Int) {
        viewModelScope.launch {
            _connectionState.value = ConnectionState.PreparingServer("Menghubungkan ke $host:$port...")

            // Ensure ADB client is connected
            if (!container.adbClient.isConnected) {
                when (val connResult = container.connectDeviceUseCase(host, port)) {
                    is AppResult.Success -> { /* connected */ }
                    is AppResult.Error -> {
                        _connectionState.value = ConnectionState.Error(
                            MirrorError.ConnectionRefused(connResult.message)
                        )
                        return@launch
                    }
                }
            }

            val config = container.preferences.mirrorConfigFlow.first()
            val decoder = videoDecoder ?: return@launch

            when (val startResult = container.startMirrorUseCase(
                config = config,
                videoDecoder = decoder,
                onProgress = { stepMessage, fraction ->
                    _connectionState.value = ConnectionState.PreparingServer(stepMessage, fraction)
                },
                onServerDied = { reason ->
                    Logger.w("Server died: $reason")
                    _connectionState.value = ConnectionState.Disconnected(reason)
                },
                onStreamError = { reason ->
                    Logger.w("Stream error: $reason")
                    _connectionState.value = ConnectionState.Disconnected(reason)
                }
            )) {
                is AppResult.Success -> {
                    activeStreamSocket = startResult.data
                    val dims = _videoDimensions.value
                    _connectionState.value = ConnectionState.MirrorRunning(
                        width = dims.first,
                        height = dims.second,
                        fps = config.maxFps,
                        bitrateMbps = config.bitRateMbps
                    )
                }
                is AppResult.Error -> {
                    _connectionState.value = ConnectionState.Error(
                        MirrorError.ServerStartFailed(startResult.message)
                    )
                }
            }
        }
    }

    fun reconnect(host: String, port: Int) {
        stopMirrorInternal()
        startMirror(host, port)
    }

    fun stopMirror() {
        stopMirrorInternal()
        _connectionState.value = ConnectionState.Disconnected("Mirror dihentikan oleh pengguna.")
    }

    private fun stopMirrorInternal() {
        container.stopMirrorUseCase(activeStreamSocket, videoDecoder)
        activeStreamSocket = null
    }

    override fun onCleared() {
        super.onCleared()
        stopMirrorInternal()
        videoDecoder?.release()
        videoDecoder = null
    }
}

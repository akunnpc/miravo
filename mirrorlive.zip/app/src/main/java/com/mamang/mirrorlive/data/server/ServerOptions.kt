package com.mamang.mirrorlive.data.server

import com.mamang.mirrorlive.core.Constants
import com.mamang.mirrorlive.domain.model.MirrorConfig

object ServerOptions {

    fun buildServerCommand(config: MirrorConfig): String {
        val args = listOf(
            "tunnel_forward=true",
            "audio=false",
            "control=false",
            "cleanup=false",
            "raw_stream=true",
            "max_size=${config.maxSize}",
            "video_bit_rate=${config.bitRate}",
            "max_fps=${config.maxFps}"
        ).joinToString(" ")

        return "CLASSPATH=${Constants.SERVER_REMOTE_PATH} app_process / com.genymobile.scrcpy.Server ${Constants.SCRCPY_VERSION} $args"
    }

    val killServerCommand: String
        get() = "pkill -f com.genymobile.scrcpy.Server || true"
}

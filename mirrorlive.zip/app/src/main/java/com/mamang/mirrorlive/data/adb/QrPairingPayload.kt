package com.mamang.mirrorlive.data.adb

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.security.SecureRandom

data class QrPairingPayload(
    val serviceName: String,
    val password: String
) {
    val rawString: String
        get() = "WIFI:T:ADB;S:$serviceName;P:$password;;"

    companion object {
        private val RANDOM = SecureRandom()
        private const val CHAR_POOL = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

        fun generate(): QrPairingPayload {
            val randomSuffix = (1..6)
                .map { CHAR_POOL[RANDOM.nextInt(CHAR_POOL.length)] }
                .joinToString("")
            val service = "mirrorlive_$randomSuffix"

            val password = (100000 + RANDOM.nextInt(900000)).toString()
            return QrPairingPayload(serviceName = service, password = password)
        }

        fun generateQrBitmap(content: String, sizePx: Int = 512): Bitmap {
            val hints = hashMapOf<EncodeHintType, Any>(
                EncodeHintType.CHARACTER_SET to "UTF-8",
                EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
                EncodeHintType.MARGIN to 2
            )
            val bitMatrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
            val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
            for (x in 0 until sizePx) {
                for (y in 0 until sizePx) {
                    bitmap.setPixel(x, y, if (bitMatrix[x, y]) Color.WHITE else Color.TRANSPARENT)
                }
            }
            return bitmap
        }
    }
}

package com.mamang.mirrorlive.ui.theme

import androidx.compose.ui.graphics.Color

val BgDark = Color(0xFF0B0F17)
val SurfaceDark = Color(0xFF131B2A)
val SurfaceVariantDark = Color(0xFF1E293B)
val SurfaceBorderDark = Color(0xFF28364F)

val PrimaryBlue = Color(0xFF38BDF8)
val PrimaryBlueVariant = Color(0xFF0284C7)
val PrimaryBlueContainer = Color(0xFF0C4A6E)

val AccentCyan = Color(0xFF06B6D4)
val AccentTeal = Color(0xFF2DD4BF)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

val SuccessGreen = Color(0xFF34D399)
val SuccessGreenContainer = Color(0xFF064E3B)

val WarningAmber = Color(0xFFFBBF24)
val WarningAmberContainer = Color(0xFF78350F)

val ErrorRed = Color(0xFFF87171)
val ErrorRedContainer = Color(0xFF7F1D1D)

val Hp1BadgeBg = Color(0xFF1E3A5F)
val Hp1BadgeText = Color(0xFF7DD3FC)
val Hp2BadgeBg = Color(0xFF134E4A)
val Hp2BadgeText = Color(0xFF5EEAD4)

package com.mamang.mirrorlive.data.adb

import com.flyfishxu.kadb.Kadb
import com.flyfishxu.kadb.shell.AdbShellResponse
import com.flyfishxu.kadb.stream.AdbStream
import com.mamang.mirrorlive.core.AppResult
import com.mamang.mirrorlive.core.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class AdbClient {

    private var activeKadb: Kadb? = null
    var connectedHost: String? = null
        private set
    var connectedPort: Int? = null
        private set

    val isConnected: Boolean
        get() = activeKadb != null

    suspend fun pair(host: String, port: Int, code: String): AppResult<Unit> = withContext(Dispatchers.IO) {
        try {
            Logger.i("Attempting ADB pairing with $host:$port using code")
            Kadb.pair(host, port, code)
            Logger.i("ADB pairing successful with $host:$port")
            AppResult.Success(Unit)
        } catch (e: Exception) {
            Logger.e("ADB pairing failed with $host:$port", e)
            AppResult.Error(e, "Pairing gagal: ${e.localizedMessage ?: "Periksa kode atau port pairing"}")
        }
    }

    suspend fun connect(host: String, port: Int): AppResult<Kadb> = withContext(Dispatchers.IO) {
        try {
            disconnect()
            Logger.i("Connecting to ADB daemon at $host:$port")
            val kadb = Kadb.create(host, port)
            // Verify connection works by running a lightweight shell check
            val checkResp = kadb.shell("echo ping")
            if (checkResp.exitCode != 0 && checkResp.output.trim() != "ping") {
                Logger.w("ADB connection check output: ${checkResp.output}, stderr: ${checkResp.errorOutput}")
            }
            activeKadb = kadb
            connectedHost = host
            connectedPort = port
            Logger.i("Connected to ADB daemon at $host:$port successfully")
            AppResult.Success(kadb)
        } catch (e: Exception) {
            Logger.e("Failed to connect to ADB daemon at $host:$port", e)
            disconnect()
            AppResult.Error(e, "Koneksi ke HP Game ($host:$port) gagal: ${e.localizedMessage}")
        }
    }

    suspend fun pushFile(localFile: File, remotePath: String): AppResult<Unit> = withContext(Dispatchers.IO) {
        val kadb = activeKadb ?: return@withContext AppResult.Error(
            IllegalStateException("AdbClient belum terhubung")
        )
        try {
            Logger.i("Pushing ${localFile.name} (${localFile.length()} bytes) to $remotePath")
            kadb.push(localFile, remotePath)
            Logger.i("Push completed successfully")
            AppResult.Success(Unit)
        } catch (e: Exception) {
            Logger.e("Push file failed", e)
            AppResult.Error(e, "Gagal mengirim file server ke HP Game: ${e.localizedMessage}")
        }
    }

    suspend fun shell(command: String): AppResult<AdbShellResponse> = withContext(Dispatchers.IO) {
        val kadb = activeKadb ?: return@withContext AppResult.Error(
            IllegalStateException("AdbClient belum terhubung")
        )
        try {
            Logger.d("Executing ADB shell: $command")
            val response = kadb.shell(command)
            AppResult.Success(response)
        } catch (e: Exception) {
            Logger.e("Shell execution failed: $command", e)
            AppResult.Error(e, "Gagal menjalankan shell: ${e.localizedMessage}")
        }
    }

    suspend fun openStream(destination: String): AppResult<AdbStream> = withContext(Dispatchers.IO) {
        val kadb = activeKadb ?: return@withContext AppResult.Error(
            IllegalStateException("AdbClient belum terhubung")
        )
        try {
            Logger.i("Opening ADB stream to destination: $destination")
            val stream = kadb.open(destination)
            AppResult.Success(stream)
        } catch (e: Exception) {
            Logger.e("Failed to open ADB stream to $destination", e)
            AppResult.Error(e, "Gagal membuka stream ADB ke $destination: ${e.localizedMessage}")
        }
    }

    fun disconnect() {
        try {
            activeKadb?.close()
        } catch (e: Exception) {
            Logger.w("Error closing Kadb instance", e)
        } finally {
            activeKadb = null
            connectedHost = null
            connectedPort = null
        }
    }
}

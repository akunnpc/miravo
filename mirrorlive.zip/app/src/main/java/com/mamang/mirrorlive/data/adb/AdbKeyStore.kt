package com.mamang.mirrorlive.data.adb

import android.content.Context
import com.flyfishxu.kadb.cert.KadbCert
import com.flyfishxu.kadb.cert.KadbCertPolicy
import com.flyfishxu.kadb.cert.OkioFilePrivateKeyStore
import com.mamang.mirrorlive.core.Logger
import okio.FileSystem
import okio.Path.Companion.toPath
import java.io.File

object AdbKeyStore {
    private var isInitialized = false

    @Synchronized
    fun initialize(context: Context) {
        if (isInitialized) return
        try {
            val keyFile = File(context.filesDir, "kadb_host_key.pem")
            val okioPath = keyFile.absolutePath.toPath()
            val store = OkioFilePrivateKeyStore(okioPath, FileSystem.SYSTEM)
            KadbCert.configure(
                store = store,
                policy = KadbCertPolicy()
            )
            KadbCert.ensureReady()
            isInitialized = true
            Logger.i("AdbKeyStore initialized with persistent key at: ${keyFile.name}")
        } catch (e: Exception) {
            Logger.e("Failed to initialize persistent Kadb key store, will use fallback", e)
            try {
                KadbCert.ensureReady()
                isInitialized = true
            } catch (e2: Exception) {
                Logger.e("Kadb fallback key generation failed", e2)
            }
        }
    }

    fun resetKeys(context: Context) {
        try {
            val keyFile = File(context.filesDir, "kadb_host_key.pem")
            if (keyFile.exists()) {
                keyFile.delete()
            }
            KadbCert.clear()
            isInitialized = false
            initialize(context)
            Logger.i("AdbKeyStore keys reset successfully")
        } catch (e: Exception) {
            Logger.e("Failed to reset ADB keys", e)
        }
    }
}

package com.mamang.mirrorlive.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.mamang.mirrorlive.core.Constants
import com.mamang.mirrorlive.domain.model.MirrorConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "mirror_settings")

class MirrorPreferences(private val context: Context) {

    companion object {
        private val KEY_IS_PAIRED = booleanPreferencesKey("is_paired")
        private val KEY_LAST_HOST = stringPreferencesKey("last_host")
        private val KEY_LAST_PORT = intPreferencesKey("last_port")
        private val KEY_MAX_SIZE = intPreferencesKey("max_size")
        private val KEY_BIT_RATE = intPreferencesKey("bit_rate")
        private val KEY_MAX_FPS = intPreferencesKey("max_fps")
    }

    val isPairedFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_IS_PAIRED] ?: false
    }

    val lastHostFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_LAST_HOST] ?: ""
    }

    val lastPortFlow: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[KEY_LAST_PORT] ?: 0
    }

    val mirrorConfigFlow: Flow<MirrorConfig> = context.dataStore.data.map { prefs ->
        MirrorConfig(
            maxSize = prefs[KEY_MAX_SIZE] ?: Constants.DEFAULT_MAX_SIZE,
            bitRate = prefs[KEY_BIT_RATE] ?: Constants.DEFAULT_BIT_RATE,
            maxFps = prefs[KEY_MAX_FPS] ?: Constants.DEFAULT_MAX_FPS
        )
    }

    suspend fun setPaired(isPaired: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_IS_PAIRED] = isPaired
        }
    }

    suspend fun saveLastConnection(host: String, port: Int) {
        context.dataStore.edit { prefs ->
            prefs[KEY_LAST_HOST] = host
            prefs[KEY_LAST_PORT] = port
        }
    }

    suspend fun updateConfig(config: MirrorConfig) {
        context.dataStore.edit { prefs ->
            prefs[KEY_MAX_SIZE] = config.maxSize
            prefs[KEY_BIT_RATE] = config.bitRate
            prefs[KEY_MAX_FPS] = config.maxFps
        }
    }

    suspend fun resetAll() {
        context.dataStore.edit { prefs ->
            prefs.clear()
        }
    }
}

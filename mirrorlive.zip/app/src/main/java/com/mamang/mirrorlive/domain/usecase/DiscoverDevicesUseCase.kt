package com.mamang.mirrorlive.domain.usecase

import com.mamang.mirrorlive.data.adb.AdbDiscovery
import com.mamang.mirrorlive.domain.model.DiscoveredDevice
import kotlinx.coroutines.flow.StateFlow

class DiscoverDevicesUseCase(
    private val discovery: AdbDiscovery
) {
    val connectDevices: StateFlow<List<DiscoveredDevice>> = discovery.connectDevices
    val pairDevices: StateFlow<List<DiscoveredDevice>> = discovery.pairDevices
    val isSearching: StateFlow<Boolean> = discovery.isSearching
    val hasTimedOut: StateFlow<Boolean> = discovery.hasTimedOut

    fun startDiscovery(timeoutMs: Long = 30_000L) {
        discovery.startDiscovery(timeoutMs)
    }

    fun stopDiscovery() {
        discovery.stopDiscovery()
    }
}

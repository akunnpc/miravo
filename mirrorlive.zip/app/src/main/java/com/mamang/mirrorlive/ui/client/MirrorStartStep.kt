package com.mamang.mirrorlive.ui.client

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mamang.mirrorlive.domain.model.MirrorConfig
import com.mamang.mirrorlive.ui.theme.AccentCyan
import com.mamang.mirrorlive.ui.theme.AccentTeal
import com.mamang.mirrorlive.ui.theme.PrimaryBlue
import com.mamang.mirrorlive.ui.theme.PrimaryBlueVariant
import com.mamang.mirrorlive.ui.theme.SuccessGreen
import com.mamang.mirrorlive.ui.theme.SurfaceBorderDark
import com.mamang.mirrorlive.ui.theme.SurfaceDark
import com.mamang.mirrorlive.ui.theme.SurfaceVariantDark
import com.mamang.mirrorlive.ui.theme.TextPrimary
import com.mamang.mirrorlive.ui.theme.TextSecondary
import com.mamang.mirrorlive.ui.theme.TextTertiary

@Composable
fun MirrorStartStep(
    connectedHost: String,
    connectedPort: Int,
    config: MirrorConfig,
    onStartMirror: () -> Unit,
    onOpenSettings: () -> Unit,
    onChangeDevice: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("mirror_start_step_container")
    ) {
        // Connected device info card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(SurfaceDark)
                .border(1.dp, SuccessGreen.copy(alpha = 0.4f), RoundedCornerShape(18.dp))
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(SuccessGreen.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.CheckCircle, null, tint = SuccessGreen, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Terhubung ke HP Game",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$connectedHost:$connectedPort",
                            style = MaterialTheme.typography.bodySmall,
                            color = AccentCyan
                        )
                    }
                }

                Text(
                    text = "Ganti",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    modifier = Modifier
                        .clickable(onClick = onChangeDevice)
                        .padding(4.dp)
                        .testTag("btn_change_device")
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Config Pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ConfigPill("Resolusi: maks ${config.maxSize}p", Modifier.weight(1f))
                ConfigPill("Bitrate: ${config.bitRateMbps} Mbps", Modifier.weight(1f))
                ConfigPill("FPS: ${config.maxFps}", Modifier.weight(1f))
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Big Primary Action Button
        Button(
            onClick = onStartMirror,
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .testTag("btn_start_mirror_fullscreen"),
            colors = ButtonDefaults.buttonColors(
                containerColor = PrimaryBlueVariant,
                contentColor = Color.White
            ),
            shape = RoundedCornerShape(16.dp),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
        ) {
            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = null,
                modifier = Modifier.size(30.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "Mulai Mirror Layar",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Small Link to Settings
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onOpenSettings)
                .padding(8.dp)
                .testTag("link_open_settings"),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Tune, null, tint = AccentTeal, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Sesuaikan Resolusi & Kualitas di Pengaturan",
                style = MaterialTheme.typography.bodySmall,
                color = AccentTeal,
                fontWeight = FontWeight.Medium
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Instructions for Live streaming
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(SurfaceDark)
                .border(1.dp, SurfaceBorderDark, RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            Column {
                Text(
                    text = "Tips Live Streaming dari HP Ini (HP 2):",
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "1. Tekan tombol Mulai Mirror Layar di atas untuk masuk ke mode layar penuh.\n" +
                            "2. Gunakan fitur Siaran Layar / Screen Share dari platform live streaming Anda (seperti TikTok Live, YouTube Live, Prism Live Studio, dll).\n" +
                            "3. Layar gameplay dari HP 1 akan ter-broadcast dengan jernih dan mulus tanpa membebani HP Game Anda.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Composable
private fun ConfigPill(text: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(SurfaceVariantDark)
            .padding(vertical = 6.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary,
            fontSize = 11.sp,
            textAlign = TextAlign.Center
        )
    }
}

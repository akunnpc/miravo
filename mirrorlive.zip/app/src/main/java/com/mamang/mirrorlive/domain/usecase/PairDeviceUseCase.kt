package com.mamang.mirrorlive.domain.usecase

import com.mamang.mirrorlive.core.AppResult
import com.mamang.mirrorlive.data.adb.AdbClient
import com.mamang.mirrorlive.data.settings.MirrorPreferences

class PairDeviceUseCase(
    private val adbClient: AdbClient,
    private val preferences: MirrorPreferences
) {
    suspend operator fun invoke(host: String, port: Int, code: String): AppResult<Unit> {
        val result = adbClient.pair(host, port, code)
        if (result is AppResult.Success) {
            preferences.setPaired(true)
            preferences.saveLastConnection(host, port)
        }
        return result
    }
}

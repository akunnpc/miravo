package com.mamang.mirrorlive.data.stream

data class VideoDimensions(
    val width: Int,
    val height: Int
)

object SpsParser {

    /**
     * Parses H.264 SPS NAL unit to extract picture width and height.
     * Expects either full NAL (with start code) or raw SPS payload starting after NAL header.
     */
    fun parseDimensions(spsBytes: ByteArray): VideoDimensions? {
        try {
            var offset = 0
            // Skip start code if present
            if (spsBytes.size >= 4 && spsBytes[0] == 0.toByte() && spsBytes[1] == 0.toByte() && spsBytes[2] == 0.toByte() && spsBytes[3] == 1.toByte()) {
                offset = 4
            } else if (spsBytes.size >= 3 && spsBytes[0] == 0.toByte() && spsBytes[1] == 0.toByte() && spsBytes[2] == 1.toByte()) {
                offset = 3
            }

            if (offset >= spsBytes.size) return null

            // NAL header (1 byte)
            val nalHeader = spsBytes[offset].toInt() and 0xFF
            val nalType = nalHeader and 0x1F
            if (nalType != 7) return null // not SPS

            offset++ // skip NAL header

            // Remove emulation prevention bytes (0x00 0x00 0x03 -> 0x00 0x00)
            val unescaped = unescapeSps(spsBytes, offset)
            val reader = BitReader(unescaped)

            val profileIdc = reader.readBits(8)
            reader.readBits(8) // constraint set flags
            reader.readBits(8) // level_idc

            reader.readExpGolomb() // seq_parameter_set_id

            if (profileIdc in listOf(100, 110, 122, 244, 44, 83, 86, 118, 128, 138, 139, 134)) {
                val chromaFormatIdc = reader.readExpGolomb()
                if (chromaFormatIdc == 3) {
                    reader.readBits(1) // separate_colour_plane_flag
                }
                reader.readExpGolomb() // bit_depth_luma_minus8
                reader.readExpGolomb() // bit_depth_chroma_minus8
                reader.readBits(1) // qpprime_y_zero_transform_bypass_flag
                val seqScalingMatrixPresent = reader.readBits(1)
                if (seqScalingMatrixPresent == 1) {
                    val count = if (chromaFormatIdc != 3) 8 else 12
                    for (i in 0 until count) {
                        val seqScalingListPresent = reader.readBits(1)
                        if (seqScalingListPresent == 1) {
                            skipScalingList(reader, if (i < 6) 16 else 64)
                        }
                    }
                }
            }

            reader.readExpGolomb() // log2_max_frame_num_minus4
            val picOrderCntType = reader.readExpGolomb()
            if (picOrderCntType == 0) {
                reader.readExpGolomb() // log2_max_pic_order_cnt_lsb_minus4
            } else if (picOrderCntType == 1) {
                reader.readBits(1) // delta_pic_order_always_zero_flag
                reader.readSignedExpGolomb() // offset_for_non_ref_pic
                reader.readSignedExpGolomb() // offset_for_top_to_bottom_field
                val numRefFramesInPicOrderCntCycle = reader.readExpGolomb()
                for (i in 0 until numRefFramesInPicOrderCntCycle) {
                    reader.readSignedExpGolomb()
                }
            }

            reader.readExpGolomb() // max_num_ref_frames
            reader.readBits(1) // gaps_in_frame_num_value_allowed_flag

            val picWidthInMbsMinus1 = reader.readExpGolomb()
            val picHeightInMapUnitsMinus1 = reader.readExpGolomb()
            val frameMbsOnlyFlag = reader.readBits(1)
            if (frameMbsOnlyFlag == 0) {
                reader.readBits(1) // mb_adaptive_frame_field_flag
            }
            reader.readBits(1) // direct_8x8_inference_flag

            var width = (picWidthInMbsMinus1 + 1) * 16
            var height = (picHeightInMapUnitsMinus1 + 1) * 16 * (2 - frameMbsOnlyFlag)

            val frameCroppingFlag = reader.readBits(1)
            if (frameCroppingFlag == 1) {
                val cropLeft = reader.readExpGolomb()
                val cropRight = reader.readExpGolomb()
                val cropTop = reader.readExpGolomb()
                val cropBottom = reader.readExpGolomb()

                val cropUnitX = 2
                val cropUnitY = 2 * (2 - frameMbsOnlyFlag)

                width -= (cropLeft + cropRight) * cropUnitX
                height -= (cropTop + cropBottom) * cropUnitY
            }

            if (width > 0 && height > 0) {
                return VideoDimensions(width, height)
            }
        } catch (_: Exception) {
            // fallback
        }
        return null
    }

    private fun skipScalingList(reader: BitReader, size: Int) {
        var lastScale = 8
        var nextScale = 8
        for (j in 0 until size) {
            if (nextScale != 0) {
                val deltaScale = reader.readSignedExpGolomb()
                nextScale = (lastScale + deltaScale + 256) % 256
            }
            lastScale = if (nextScale == 0) lastScale else nextScale
        }
    }

    private fun unescapeSps(bytes: ByteArray, offset: Int): ByteArray {
        val out = ArrayList<Byte>(bytes.size - offset)
        var i = offset
        while (i < bytes.size) {
            if (i + 2 < bytes.size && bytes[i] == 0.toByte() && bytes[i + 1] == 0.toByte() && bytes[i + 2] == 3.toByte()) {
                out.add(0.toByte())
                out.add(0.toByte())
                i += 3 // Skip 0x03 emulation byte
            } else {
                out.add(bytes[i])
                i++
            }
        }
        return out.toByteArray()
    }

    private class BitReader(private val bytes: ByteArray) {
        private var byteOffset = 0
        private var bitOffset = 0

        fun readBits(n: Int): Int {
            var value = 0
            for (i in 0 until n) {
                if (byteOffset >= bytes.size) return value
                val currentByte = bytes[byteOffset].toInt() and 0xFF
                val bit = (currentByte shr (7 - bitOffset)) and 1
                value = (value shl 1) or bit
                bitOffset++
                if (bitOffset == 8) {
                    bitOffset = 0
                    byteOffset++
                }
            }
            return value
        }

        fun readExpGolomb(): Int {
            var leadingZeros = 0
            while (readBits(1) == 0 && leadingZeros < 32) {
                leadingZeros++
            }
            if (leadingZeros == 0) return 0
            val rest = readBits(leadingZeros)
            return (1 shl leadingZeros) - 1 + rest
        }

        fun readSignedExpGolomb(): Int {
            val codeNum = readExpGolomb()
            val sign = if (codeNum % 2 == 1) 1 else -1
            return sign * ((codeNum + 1) / 2)
        }
    }
}

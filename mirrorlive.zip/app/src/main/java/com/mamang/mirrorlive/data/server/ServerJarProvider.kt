package com.mamang.mirrorlive.data.server

import android.content.Context
import com.mamang.mirrorlive.core.AppResult
import com.mamang.mirrorlive.core.Constants
import com.mamang.mirrorlive.core.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

class ServerJarProvider(private val context: Context) {

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    val localJarFile: File
        get() = File(context.filesDir, Constants.SERVER_JAR_FILE_NAME)

    fun isJarAvailable(): Boolean {
        val file = localJarFile
        return file.exists() && file.length() > 50_000 // legitimate scrcpy server is ~700KB
    }

    suspend fun obtainServerJar(
        onProgress: (progress: Float) -> Unit = {}
    ): AppResult<File> = withContext(Dispatchers.IO) {
        val targetFile = localJarFile

        // 1. If already valid in filesDir, return it
        if (isJarAvailable()) {
            Logger.i("scrcpy-server jar found in filesDir: ${targetFile.absolutePath} (${targetFile.length()} bytes)")
            onProgress(1.0f)
            return@withContext AppResult.Success(targetFile)
        }

        // 2. Check if pre-bundled in assets
        try {
            val assetNames = context.assets.list("") ?: emptyArray()
            if (Constants.SERVER_JAR_ASSET_NAME in assetNames) {
                Logger.i("Extracting ${Constants.SERVER_JAR_ASSET_NAME} from assets...")
                context.assets.open(Constants.SERVER_JAR_ASSET_NAME).use { input ->
                    FileOutputStream(targetFile).use { output ->
                        val buffer = ByteArray(8192)
                        var bytesRead: Int
                        var totalRead = 0L
                        val estimatedTotal = 730_000L
                        while (input.read(buffer).also { bytesRead = it } != -1) {
                            output.write(buffer, 0, bytesRead)
                            totalRead += bytesRead
                            onProgress((totalRead.toFloat() / estimatedTotal).coerceIn(0f, 0.99f))
                        }
                        output.flush()
                    }
                }
                if (isJarAvailable()) {
                    Logger.i("Successfully extracted scrcpy-server jar from assets (${targetFile.length()} bytes)")
                    onProgress(1.0f)
                    return@withContext AppResult.Success(targetFile)
                }
            }
        } catch (e: Exception) {
            Logger.w("Could not extract scrcpy-server from assets, will attempt download", e)
        }

        // 3. Fallback: Download from GitHub Releases
        Logger.i("Downloading scrcpy-server v${Constants.SCRCPY_VERSION} from ${Constants.SERVER_DOWNLOAD_URL}...")
        try {
            val request = Request.Builder()
                .url(Constants.SERVER_DOWNLOAD_URL)
                .header("User-Agent", "MirrorLive-Android/${Constants.SCRCPY_VERSION}")
                .build()

            val response = okHttpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                val errorMsg = "Gagal mengunduh scrcpy-server: HTTP ${response.code}"
                Logger.e(errorMsg)
                return@withContext AppResult.Error(
                    IllegalStateException(errorMsg),
                    "Gagal mengunduh server jar dari GitHub (HTTP ${response.code}). Periksa koneksi internet."
                )
            }

            val body = response.body ?: return@withContext AppResult.Error(
                IllegalStateException("Response body null"),
                "File server yang diunduh kosong."
            )

            val contentLength = body.contentLength()
            val tempFile = File(context.filesDir, "${Constants.SERVER_JAR_FILE_NAME}.tmp")

            body.byteStream().use { input ->
                FileOutputStream(tempFile).use { output ->
                    val buffer = ByteArray(8192)
                    var bytesRead: Int
                    var totalRead = 0L
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        output.write(buffer, 0, bytesRead)
                        totalRead += bytesRead
                        if (contentLength > 0) {
                            onProgress(totalRead.toFloat() / contentLength)
                        }
                    }
                    output.flush()
                }
            }

            if (tempFile.length() < 50_000) {
                tempFile.delete()
                val errorMsg = "File hasil unduhan terlalu kecil (${tempFile.length()} bytes), kemungkinan korup"
                Logger.e(errorMsg)
                return@withContext AppResult.Error(IllegalStateException(errorMsg), errorMsg)
            }

            if (targetFile.exists()) {
                targetFile.delete()
            }
            if (!tempFile.renameTo(targetFile)) {
                tempFile.copyTo(targetFile, overwrite = true)
                tempFile.delete()
            }

            Logger.i("Downloaded and saved scrcpy-server v${Constants.SCRCPY_VERSION} (${targetFile.length()} bytes)")
            onProgress(1.0f)
            AppResult.Success(targetFile)
        } catch (e: Exception) {
            Logger.e("Exception downloading scrcpy-server jar", e)
            AppResult.Error(
                e,
                "Gagal mengunduh server jar: ${e.localizedMessage ?: "Koneksi terputus"}. Silakan coba lagi."
            )
        }
    }
}

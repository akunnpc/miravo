package com.mamang.mirrorlive.ui.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mamang.mirrorlive.core.AppContainer
import com.mamang.mirrorlive.core.AppResult
import com.mamang.mirrorlive.core.Constants
import com.mamang.mirrorlive.data.adb.AdbKeyStore
import com.mamang.mirrorlive.domain.model.MirrorConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val container = AppContainer.getInstance(application)

    val mirrorConfig: StateFlow<MirrorConfig> = container.preferences.mirrorConfigFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, MirrorConfig())

    private val _downloadProgress = MutableStateFlow<Float?>(null)
    val downloadProgress: StateFlow<Float?> = _downloadProgress.asStateFlow()

    private val _serverJarStatus = MutableStateFlow(checkServerJarStatus())
    val serverJarStatus: StateFlow<String> = _serverJarStatus.asStateFlow()

    fun updateMaxSize(maxSize: Int) {
        viewModelScope.launch {
            val curr = mirrorConfig.value
            container.preferences.updateConfig(curr.copy(maxSize = maxSize))
        }
    }

    fun updateBitRate(bitRate: Int) {
        viewModelScope.launch {
            val curr = mirrorConfig.value
            container.preferences.updateConfig(curr.copy(bitRate = bitRate))
        }
    }

    fun updateFps(fps: Int) {
        viewModelScope.launch {
            val curr = mirrorConfig.value
            container.preferences.updateConfig(curr.copy(maxFps = fps))
        }
    }

    fun redownloadServerJar() {
        viewModelScope.launch {
            _downloadProgress.value = 0.05f
            val file = container.serverJarProvider.localJarFile
            if (file.exists()) {
                file.delete()
            }
            when (val res = container.serverJarProvider.obtainServerJar { p -> _downloadProgress.value = p }) {
                is AppResult.Success -> {
                    _downloadProgress.value = null
                    _serverJarStatus.value = "Tersedia (${res.data.length() / 1024} KB) - v${Constants.SCRCPY_VERSION}"
                }
                is AppResult.Error -> {
                    _downloadProgress.value = null
                    _serverJarStatus.value = "Gagal mengunduh: ${res.message}"
                }
            }
        }
    }

    fun resetPairing() {
        viewModelScope.launch {
            container.preferences.setPaired(false)
            AdbKeyStore.resetKeys(getApplication())
        }
    }

    private fun checkServerJarStatus(): String {
        return if (container.serverJarProvider.isJarAvailable()) {
            val sizeKb = container.serverJarProvider.localJarFile.length() / 1024
            "Siap digunakan (${sizeKb} KB) - scrcpy-server v${Constants.SCRCPY_VERSION}"
        } else {
            "Belum siap (akan diekstrak otomatis saat pertama kali digunakan)"
        }
    }
}

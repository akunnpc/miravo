package com.mamang.mirrorlive.domain.model

sealed class MirrorError(val message: String, val recoveryHint: String? = null) {
    data class NetworkNotWifi(val detail: String = "HP 2 tidak terhubung ke jaringan Wi-Fi.") :
        MirrorError(detail, "Hubungkan kedua HP ke Wi-Fi atau hotspot yang sama.")

    data class ServerJarMissing(val detail: String) :
        MirrorError(detail, "Coba unduh ulang scrcpy-server dari pengaturan.")

    data class DownloadFailed(val detail: String) :
        MirrorError(detail, "Pastikan koneksi internet aktif lalu coba lagi.")

    data class VersionMismatch(val detail: String) :
        MirrorError(detail, "Periksa kompatibilitas versi scrcpy-server v4.0.")

    data class PairingFailed(val detail: String) :
        MirrorError(detail, "Periksa kode pairing atau pastikan HP 1 belum menutup layar pairing.")

    data class DeviceNotFound(val detail: String) :
        MirrorError(detail, "Pastikan 'Proses debug nirkabel' di HP 1 aktif dan berada di Wi-Fi yang sama.")

    data class ConnectionRefused(val detail: String) :
        MirrorError(detail, "Periksa port Wireless Debugging di HP 1. Port sering berubah saat Wi-Fi tersambung ulang.")

    data class ServerStartFailed(val detail: String) :
        MirrorError(detail, "Pastikan izin Wireless Debugging diizinkan pada HP 1.")

    data class StreamClosed(val detail: String) :
        MirrorError(detail, "Koneksi stream terputus secara tiba-tiba. Tekan Hubungkan Ulang.")

    data class DecoderFailed(val detail: String) :
        MirrorError(detail, "Decoder video hardware gagal. Coba turunkan resolusi.")

    data class Unknown(val detail: String) :
        MirrorError(detail, "Silakan coba lagi.")
}

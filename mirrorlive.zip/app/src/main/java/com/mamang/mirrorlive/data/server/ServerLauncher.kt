package com.mamang.mirrorlive.data.server

import com.mamang.mirrorlive.core.AppResult
import com.mamang.mirrorlive.core.Constants
import com.mamang.mirrorlive.core.Logger
import com.mamang.mirrorlive.data.adb.AdbClient
import com.mamang.mirrorlive.domain.model.MirrorConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

class ServerLauncher(
    private val adbClient: AdbClient
) {
    private var serverJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    suspend fun prepareAndPushJar(jarFile: File): AppResult<Unit> {
        Logger.i("Pushing scrcpy-server jar to HP 1 (${Constants.SERVER_REMOTE_PATH})")
        return adbClient.pushFile(jarFile, Constants.SERVER_REMOTE_PATH)
    }

    fun startServer(
        config: MirrorConfig,
        onServerDied: (reason: String) -> Unit
    ): Job {
        stopServer()

        val command = ServerOptions.buildServerCommand(config)
        Logger.i("Starting scrcpy-server on HP 1 with command: $command")

        val job = scope.launch {
            try {
                // Kill any stale instance first
                adbClient.shell(ServerOptions.killServerCommand)
                delay(200)

                val response = adbClient.shell(command)
                val exitCode = (response as? AppResult.Success)?.data?.exitCode ?: -1
                val allOut = (response as? AppResult.Success)?.data?.output ?: ""
                Logger.w("Server process finished. Exit: $exitCode, Out: $allOut")
                if (isActive) {
                    onServerDied("Server scrcpy di HP 1 berhenti (exit code: $exitCode)")
                }
            } catch (e: Exception) {
                Logger.e("Exception running server process on HP 1", e)
                if (isActive) {
                    onServerDied("Kesalahan proses server di HP 1: ${e.localizedMessage}")
                }
            }
        }
        serverJob = job
        return job
    }

    fun stopServer() {
        serverJob?.cancel()
        serverJob = null
        scope.launch {
            try {
                adbClient.shell(ServerOptions.killServerCommand)
                Logger.i("Sent kill command to scrcpy server on HP 1")
            } catch (e: Exception) {
                Logger.w("Failed to send kill command to server", e)
            }
        }
    }
}

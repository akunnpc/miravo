package com.mamang.mirrorlive.domain.model

data class DiscoveredDevice(
    val id: String,
    val name: String,
    val host: String,
    val port: Int,
    val isPairingService: Boolean = false,
    val lastSeenTimestamp: Long = System.currentTimeMillis()
)

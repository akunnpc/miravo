package com.mamang.mirrorlive.domain.usecase

import com.mamang.mirrorlive.data.server.ServerLauncher
import com.mamang.mirrorlive.data.stream.StreamSocket
import com.mamang.mirrorlive.media.VideoDecoder

class StopMirrorUseCase(
    private val serverLauncher: ServerLauncher
) {
    operator fun invoke(
        streamSocket: StreamSocket?,
        videoDecoder: VideoDecoder?
    ) {
        streamSocket?.close()
        videoDecoder?.release()
        serverLauncher.stopServer()
    }
}

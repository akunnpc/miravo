package com.mamang.mirrorlive.data.stream

import java.io.ByteArrayOutputStream

data class NalUnit(
    val data: ByteArray,
    val type: Int,
    val isKeyFrame: Boolean
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as NalUnit
        return data.contentEquals(other.data) && type == other.type
    }

    override fun hashCode(): Int {
        var result = data.contentHashCode()
        result = 31 * result + type
        return result
    }
}

class AnnexBParser(
    private val onNalUnit: (NalUnit) -> Unit
) {
    private val buffer = ByteArrayOutputStream(64 * 1024)
    private var zeros = 0
    private var startCodeFound = false

    fun parse(bytes: ByteArray, offset: Int = 0, length: Int = bytes.size) {
        var i = offset
        val end = offset + length

        while (i < end) {
            val b = bytes[i].toInt() and 0xFF

            if (b == 0) {
                zeros++
            } else if (b == 1 && zeros >= 2) {
                // Found a start code: 00 00 01 or 00 00 00 01
                val startCodeLen = if (zeros >= 3) 4 else 3
                if (startCodeFound) {
                    val accumulated = buffer.toByteArray()
                    // Strip the trailing zeros from the previous NAL unit
                    val nalLength = accumulated.size - zeros
                    if (nalLength > 0) {
                        val nalData = ByteArray(nalLength)
                        System.arraycopy(accumulated, 0, nalData, 0, nalLength)
                        emitNalUnit(nalData)
                    }
                    buffer.reset()
                }

                // Append the start code for the new NAL unit
                if (startCodeLen == 4) {
                    buffer.write(0)
                }
                buffer.write(0)
                buffer.write(0)
                buffer.write(1)

                startCodeFound = true
                zeros = 0
            } else {
                // Regular byte
                if (startCodeFound) {
                    while (zeros > 0) {
                        buffer.write(0)
                        zeros--
                    }
                    buffer.write(b)
                }
                zeros = 0
            }
            i++
        }
    }

    private fun emitNalUnit(nalData: ByteArray) {
        if (nalData.size < 4) return

        // Skip start code prefix to read NAL header
        var headerIndex = 0
        if (nalData.size >= 4 && nalData[0] == 0.toByte() && nalData[1] == 0.toByte() && nalData[2] == 0.toByte() && nalData[3] == 1.toByte()) {
            headerIndex = 4
        } else if (nalData.size >= 3 && nalData[0] == 0.toByte() && nalData[1] == 0.toByte() && nalData[2] == 1.toByte()) {
            headerIndex = 3
        }

        if (headerIndex >= nalData.size) return

        val headerByte = nalData[headerIndex].toInt() and 0xFF
        val nalType = headerByte and 0x1F
        val isKeyFrame = nalType == 5 || nalType == 7 // IDR or SPS

        onNalUnit(
            NalUnit(
                data = nalData,
                type = nalType,
                isKeyFrame = isKeyFrame
            )
        )
    }

    fun flush() {
        if (startCodeFound && buffer.size() > 0) {
            val accumulated = buffer.toByteArray()
            val nalLength = accumulated.size - zeros
            if (nalLength > 0) {
                val nalData = ByteArray(nalLength)
                System.arraycopy(accumulated, 0, nalData, 0, nalLength)
                emitNalUnit(nalData)
            }
            buffer.reset()
        }
        startCodeFound = false
        zeros = 0
    }
}

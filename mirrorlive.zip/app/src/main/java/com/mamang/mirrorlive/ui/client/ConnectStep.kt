package com.mamang.mirrorlive.ui.client

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mamang.mirrorlive.domain.model.DiscoveredDevice
import com.mamang.mirrorlive.ui.theme.AccentCyan
import com.mamang.mirrorlive.ui.theme.PrimaryBlue
import com.mamang.mirrorlive.ui.theme.PrimaryBlueVariant
import com.mamang.mirrorlive.ui.theme.SuccessGreen
import com.mamang.mirrorlive.ui.theme.SurfaceBorderDark
import com.mamang.mirrorlive.ui.theme.SurfaceDark
import com.mamang.mirrorlive.ui.theme.SurfaceVariantDark
import com.mamang.mirrorlive.ui.theme.TextPrimary
import com.mamang.mirrorlive.ui.theme.TextSecondary
import com.mamang.mirrorlive.ui.theme.WarningAmber

@Composable
fun ConnectStep(
    devices: List<DiscoveredDevice>,
    isSearching: Boolean,
    hasTimedOut: Boolean,
    lastHost: String,
    lastPort: Int,
    onRefreshDiscovery: () -> Unit,
    onConnectDevice: (host: String, port: Int, name: String) -> Unit,
    onBackToPairing: () -> Unit,
    modifier: Modifier = Modifier
) {
    var manualHost by remember(lastHost) { mutableStateOf(lastHost) }
    var manualPort by remember(lastPort) { mutableStateOf(if (lastPort > 0) lastPort.toString() else "") }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("connect_step_container")
    ) {
        // Quick connect last device banner (if available)
        if (lastHost.isNotBlank() && lastPort > 0) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(PrimaryBlue.copy(alpha = 0.1f))
                    .border(1.dp, PrimaryBlue.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(PrimaryBlue.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Bolt, null, tint = PrimaryBlue, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Koneksi Terakhir",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$lastHost:$lastPort",
                            style = MaterialTheme.typography.bodySmall,
                            color = AccentCyan
                        )
                    }
                }

                FilledTonalButton(
                    onClick = { onConnectDevice(lastHost, lastPort, "HP Game (Terakhir)") },
                    modifier = Modifier.testTag("btn_quick_connect"),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = PrimaryBlueVariant,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Hubungkan", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(18.dp))
        }

        // Section 1: Discovered Devices via mDNS
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Ditemukan Otomatis (mDNS)",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                if (isSearching) {
                    Spacer(modifier = Modifier.width(8.dp))
                    CircularProgressIndicator(
                        modifier = Modifier.size(14.dp),
                        color = PrimaryBlue,
                        strokeWidth = 2.dp
                    )
                }
            }

            IconButton(
                onClick = onRefreshDiscovery,
                modifier = Modifier.size(28.dp).testTag("btn_refresh_discovery")
            ) {
                Icon(Icons.Default.Refresh, "Pindai ulang", tint = AccentCyan, modifier = Modifier.size(18.dp))
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (devices.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                devices.forEach { dev ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SurfaceDark)
                            .border(1.dp, SurfaceBorderDark, RoundedCornerShape(12.dp))
                            .clickable { onConnectDevice(dev.host, dev.port, dev.name) }
                            .padding(14.dp)
                            .testTag("device_item_${dev.host}"),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(SuccessGreen.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.PhoneAndroid, null, tint = SuccessGreen, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = dev.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${dev.host}:${dev.port}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }

                        Button(
                            onClick = { onConnectDevice(dev.host, dev.port, dev.name) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = PrimaryBlueVariant,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("btn_connect_${dev.host}")
                        ) {
                            Text("Pilih", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        } else {
            // Empty state or searching
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(SurfaceDark)
                    .border(1.dp, SurfaceBorderDark, RoundedCornerShape(12.dp))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (isSearching) {
                        Text(
                            text = "Mencari HP 1 di jaringan Wi-Fi...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    } else if (hasTimedOut) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, null, tint = WarningAmber, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Layanan mDNS tidak ditemukan (30 dtk).",
                                style = MaterialTheme.typography.bodySmall,
                                color = WarningAmber,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Gunakan input manual di bawah ini.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    } else {
                        Text(
                            text = "Belum ada HP Game yang terdeteksi.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Section 2: Input Manual
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(SurfaceDark)
                .border(1.dp, SurfaceBorderDark, RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Text(
                text = "Input Manual (IP & Port)",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Lihat di HP 1: Opsi Pengembang > Proses debug nirkabel > bagian 'Alamat IP & Port'.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = manualHost,
                onValueChange = { manualHost = it },
                label = { Text("Alamat IP HP 1 (Game)") },
                placeholder = { Text("Contoh: 192.168.1.15") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_connect_ip"),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = SurfaceBorderDark
                ),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = manualPort,
                onValueChange = { manualPort = it },
                label = { Text("Port Wireless Debugging HP 1") },
                placeholder = { Text("Port acak (misal: 41235)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_connect_port"),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = SurfaceBorderDark
                ),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = {
                    val p = manualPort.toIntOrNull() ?: 0
                    onConnectDevice(manualHost.trim(), p, "HP Game")
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_submit_manual_connect"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = PrimaryBlueVariant,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Hubungkan ke HP Game", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Small re-pairing link
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            OutlinedButton(
                onClick = onBackToPairing,
                modifier = Modifier.testTag("btn_re_pair"),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Pairing Ulang dengan QR", fontSize = 12.sp, color = TextSecondary)
            }
        }
    }
}

package com.mamang.mirrorlive.domain.model

sealed class ConnectionState {
    object Idle : ConnectionState()

    data class WaitingQrScan(
        val serviceName: String,
        val password: String,
        val qrPayloadString: String
    ) : ConnectionState()

    data class PairingInProgress(val host: String, val port: Int) : ConnectionState()

    data class PairingSuccess(val host: String, val deviceName: String = "HP Game") : ConnectionState()

    data class SearchingDevice(val message: String = "Mencari HP 1 lewat mDNS...") : ConnectionState()

    data class PreparingServer(val stepMessage: String, val progressFraction: Float? = null) : ConnectionState()

    data class Connected(
        val deviceName: String,
        val host: String,
        val port: Int
    ) : ConnectionState()

    data class MirrorRunning(
        val width: Int = 0,
        val height: Int = 0,
        val fps: Int = 0,
        val bitrateMbps: Int = 8
    ) : ConnectionState()

    data class Disconnected(val reason: String = "Koneksi terputus") : ConnectionState()

    data class Error(val error: MirrorError) : ConnectionState()

    val isMirroring: Boolean get() = this is MirrorRunning
    val isConnected: Boolean get() = this is Connected || this is MirrorRunning
}

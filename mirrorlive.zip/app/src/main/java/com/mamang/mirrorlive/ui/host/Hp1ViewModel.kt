package com.mamang.mirrorlive.ui.host

import android.app.Application
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mamang.mirrorlive.core.NetworkUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class Hp1SetupState(
    val isDeveloperOptionsEnabled: Boolean,
    val isWirelessDebuggingConfirmed: Boolean,
    val localIp: String?,
    val isWifi: Boolean
)

class Hp1ViewModel(application: Application) : AndroidViewModel(application) {

    private val _state = MutableStateFlow(checkEnvironment(previousConfirmed = false))
    val state: StateFlow<Hp1SetupState> = _state.asStateFlow()

    fun refreshState() {
        _state.value = checkEnvironment(previousConfirmed = _state.value.isWirelessDebuggingConfirmed)
    }

    fun toggleWirelessDebuggingManual(confirmed: Boolean) {
        _state.value = _state.value.copy(isWirelessDebuggingConfirmed = confirmed)
    }

    private fun checkEnvironment(previousConfirmed: Boolean = false): Hp1SetupState {
        val context = getApplication<Application>()
        val cr = context.contentResolver

        // 1. Detect Developer Options
        val devEnabled = try {
            Settings.Global.getInt(cr, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        } catch (_: Exception) {
            false
        }

        // 2. Try to detect wireless debugging (Settings.Global "adb_wifi_enabled")
        val adbWifi = try {
            Settings.Global.getInt(cr, "adb_wifi_enabled", 0) == 1
        } catch (_: Exception) {
            false
        }

        // 3. Network status
        val netStatus = NetworkUtils.getNetworkStatus(context)

        return Hp1SetupState(
            isDeveloperOptionsEnabled = devEnabled,
            isWirelessDebuggingConfirmed = adbWifi || previousConfirmed,
            localIp = netStatus.localIp,
            isWifi = netStatus.isWifi
        )
    }
}

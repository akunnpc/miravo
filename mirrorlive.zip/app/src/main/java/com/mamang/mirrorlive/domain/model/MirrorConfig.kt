package com.mamang.mirrorlive.domain.model

import com.mamang.mirrorlive.core.Constants

data class MirrorConfig(
    val maxSize: Int = Constants.DEFAULT_MAX_SIZE,
    val bitRate: Int = Constants.DEFAULT_BIT_RATE,
    val maxFps: Int = Constants.DEFAULT_MAX_FPS
) {
    val bitRateMbps: Int get() = bitRate / 1_000_000
}

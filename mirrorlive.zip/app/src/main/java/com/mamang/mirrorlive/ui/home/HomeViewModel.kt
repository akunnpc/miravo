package com.mamang.mirrorlive.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mamang.mirrorlive.core.AppContainer
import com.mamang.mirrorlive.core.NetworkStatus
import com.mamang.mirrorlive.core.NetworkUtils
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val container = AppContainer.getInstance(application)

    val networkStatus: StateFlow<NetworkStatus> = NetworkUtils.observeNetworkStatus(application)
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            NetworkUtils.getNetworkStatus(application)
        )

    val isPaired: StateFlow<Boolean> = container.preferences.isPairedFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
}

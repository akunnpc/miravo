package com.mamang.mirrorlive.ui.client

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mamang.mirrorlive.ui.components.StatusCard
import com.mamang.mirrorlive.ui.components.StepIndicator
import com.mamang.mirrorlive.ui.theme.AccentCyan
import com.mamang.mirrorlive.ui.theme.BgDark
import com.mamang.mirrorlive.ui.theme.Hp2BadgeBg
import com.mamang.mirrorlive.ui.theme.Hp2BadgeText
import com.mamang.mirrorlive.ui.theme.TextPrimary
import com.mamang.mirrorlive.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Hp2WizardScreen(
    onNavigateBack: () -> Unit,
    onStartMirror: (host: String, port: Int) -> Unit,
    onNavigateToSettings: () -> Unit,
    viewModel: Hp2ViewModel = viewModel()
) {
    val currentStep by viewModel.currentStep.collectAsStateWithLifecycle()
    val connectionState by viewModel.connectionState.collectAsStateWithLifecycle()
    val qrPayload by viewModel.qrPayload.collectAsStateWithLifecycle()
    val qrBitmap by viewModel.qrBitmap.collectAsStateWithLifecycle()
    val isAlreadyPaired by viewModel.isAlreadyPaired.collectAsStateWithLifecycle()
    val lastHost by viewModel.lastHost.collectAsStateWithLifecycle()
    val lastPort by viewModel.lastPort.collectAsStateWithLifecycle()
    val mirrorConfig by viewModel.mirrorConfig.collectAsStateWithLifecycle()
    val connectDevices by viewModel.connectDevices.collectAsStateWithLifecycle()
    val isSearchingMdns by viewModel.isSearchingMdns.collectAsStateWithLifecycle()
    val hasMdnsTimedOut by viewModel.hasMdnsTimedOut.collectAsStateWithLifecycle()

    BackHandler {
        if (currentStep > 1) {
            viewModel.goToStep(currentStep - 1)
        } else {
            onNavigateBack()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Hp2BadgeBg)
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "HP 2",
                                style = MaterialTheme.typography.labelSmall,
                                color = Hp2BadgeText,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "HP Live (Klien Mirror)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (currentStep > 1) {
                                viewModel.goToStep(currentStep - 1)
                            } else {
                                onNavigateBack()
                            }
                        },
                        modifier = Modifier.testTag("hp2_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Kembali",
                            tint = TextPrimary
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = onNavigateToSettings,
                        modifier = Modifier.testTag("hp2_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Pengaturan",
                            tint = TextSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = BgDark,
                    titleContentColor = TextPrimary
                )
            )
        },
        containerColor = BgDark
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Stepper Indicator: 1 Pairing > 2 Hubungkan > 3 Mirror
            StepIndicator(currentStep = currentStep)

            Spacer(modifier = Modifier.height(16.dp))

            // Real-time Status Card
            StatusCard(
                state = connectionState,
                onRetry = { viewModel.retryCurrentAction() }
            )

            Spacer(modifier = Modifier.height(20.dp))

            when (currentStep) {
                1 -> {
                    PairingQrStep(
                        qrPayload = qrPayload,
                        qrBitmap = qrBitmap,
                        isAlreadyPaired = isAlreadyPaired,
                        onRefreshQr = { viewModel.generateNewQr() },
                        onPairWithCode = { host, port, code ->
                            viewModel.pairWithCode(host, port, code)
                        },
                        onSkipToStep2 = {
                            viewModel.goToStep(2)
                        }
                    )
                }
                2 -> {
                    ConnectStep(
                        devices = connectDevices,
                        isSearching = isSearchingMdns,
                        hasTimedOut = hasMdnsTimedOut,
                        lastHost = lastHost,
                        lastPort = lastPort,
                        onRefreshDiscovery = { viewModel.startDeviceDiscovery() },
                        onConnectDevice = { host, port, name ->
                            viewModel.connectToDevice(host, port, name)
                        },
                        onBackToPairing = { viewModel.goToStep(1) }
                    )
                }
                3 -> {
                    MirrorStartStep(
                        connectedHost = lastHost,
                        connectedPort = lastPort,
                        config = mirrorConfig,
                        onStartMirror = {
                            onStartMirror(lastHost, lastPort)
                        },
                        onOpenSettings = onNavigateToSettings,
                        onChangeDevice = { viewModel.goToStep(2) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

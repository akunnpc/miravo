package com.mamang.mirrorlive.core

object Constants {
    const val SCRCPY_VERSION = "4.0"
    const val SERVER_JAR_ASSET_NAME = "scrcpy-server-v4.0"
    const val SERVER_JAR_FILE_NAME = "scrcpy-server-v4.0.jar"
    const val SERVER_REMOTE_PATH = "/data/local/tmp/scrcpy-server.jar"
    const val SERVER_DOWNLOAD_URL = "https://github.com/Genymobile/scrcpy/releases/download/v4.0/scrcpy-server-v4.0"

    const val DEFAULT_MAX_SIZE = 1280
    const val DEFAULT_BIT_RATE = 8_000_000 // 8 Mbps
    const val DEFAULT_MAX_FPS = 60

    const val ABSTRACT_SOCKET_NAME = "scrcpy"
    const val ADB_LOCALABSTRACT_DEST = "localabstract:scrcpy"

    const val MDNS_PAIRING_SERVICE = "_adb-tls-pairing._tcp"
    const val MDNS_CONNECT_SERVICE = "_adb-tls-connect._tcp"

    const val MAX_CONNECT_RETRIES = 12
    const val RETRY_DELAY_MS = 400L
}

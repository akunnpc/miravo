package com.mamang.mirrorlive

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mamang.mirrorlive.core.AppContainer
import com.mamang.mirrorlive.ui.client.Hp2WizardScreen
import com.mamang.mirrorlive.ui.home.HomeScreen
import com.mamang.mirrorlive.ui.host.Hp1GuideScreen
import com.mamang.mirrorlive.ui.mirror.MirrorScreen
import com.mamang.mirrorlive.ui.settings.SettingsScreen
import com.mamang.mirrorlive.ui.theme.BgDark
import com.mamang.mirrorlive.ui.theme.MirrorLiveTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Warm up dependency container
        AppContainer.getInstance(this)

        setContent {
            MirrorLiveTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = BgDark
                ) {
                    val navController = rememberNavController()

                    NavHost(
                        navController = navController,
                        startDestination = "home"
                    ) {
                        composable("home") {
                            HomeScreen(
                                onNavigateToHp1Guide = {
                                    navController.navigate("hp1_guide")
                                },
                                onNavigateToHp2Wizard = {
                                    navController.navigate("hp2_wizard")
                                },
                                onNavigateToSettings = {
                                    navController.navigate("settings")
                                }
                            )
                        }

                        composable("hp1_guide") {
                            Hp1GuideScreen(
                                onNavigateBack = {
                                    navController.popBackStack()
                                }
                            )
                        }

                        composable("hp2_wizard") {
                            Hp2WizardScreen(
                                onNavigateBack = {
                                    navController.popBackStack()
                                },
                                onStartMirror = { host, port ->
                                    navController.navigate("mirror/$host/$port")
                                },
                                onNavigateToSettings = {
                                    navController.navigate("settings")
                                }
                            )
                        }

                        composable(
                            route = "mirror/{host}/{port}",
                            arguments = listOf(
                                navArgument("host") { type = NavType.StringType },
                                navArgument("port") { type = NavType.IntType }
                            )
                        ) { backStackEntry ->
                            val host = backStackEntry.arguments?.getString("host") ?: ""
                            val port = backStackEntry.arguments?.getInt("port") ?: 0

                            MirrorScreen(
                                host = host,
                                port = port,
                                onNavigateBack = {
                                    navController.popBackStack()
                                },
                                onNavigateToSettings = {
                                    navController.navigate("settings")
                                }
                            )
                        }

                        composable("settings") {
                            SettingsScreen(
                                onNavigateBack = {
                                    navController.popBackStack()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

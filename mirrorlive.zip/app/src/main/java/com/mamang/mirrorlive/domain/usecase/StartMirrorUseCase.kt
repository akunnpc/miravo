package com.mamang.mirrorlive.domain.usecase

import com.mamang.mirrorlive.core.AppResult
import com.mamang.mirrorlive.core.Logger
import com.mamang.mirrorlive.data.adb.AdbClient
import com.mamang.mirrorlive.data.server.ServerJarProvider
import com.mamang.mirrorlive.data.server.ServerLauncher
import com.mamang.mirrorlive.data.stream.StreamSocket
import com.mamang.mirrorlive.domain.model.MirrorConfig
import com.mamang.mirrorlive.media.VideoDecoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class StartMirrorUseCase(
    private val adbClient: AdbClient,
    private val serverJarProvider: ServerJarProvider,
    private val serverLauncher: ServerLauncher
) {
    suspend operator fun invoke(
        config: MirrorConfig,
        videoDecoder: VideoDecoder,
        onProgress: (stepMessage: String, fraction: Float?) -> Unit,
        onServerDied: (reason: String) -> Unit,
        onStreamError: (reason: String) -> Unit
    ): AppResult<StreamSocket> = withContext(Dispatchers.IO) {
        if (!adbClient.isConnected) {
            return@withContext AppResult.Error(
                IllegalStateException("ADB belum terhubung"),
                "Koneksi ADB ke HP Game terputus. Silakan hubungkan kembali."
            )
        }

        // 1. Obtain Server Jar (from assets or GitHub download)
        onProgress("Memeriksa file scrcpy-server v4.0...", 0.1f)
        val jarResult = serverJarProvider.obtainServerJar { downloadFraction ->
            onProgress("Mengunduh server jar (${(downloadFraction * 100).toInt()}%)...", 0.1f + downloadFraction * 0.3f)
        }

        val jarFile = when (jarResult) {
            is AppResult.Success -> jarResult.data
            is AppResult.Error -> return@withContext jarResult
        }

        // 2. Push jar to HP 1 (/data/local/tmp/scrcpy-server.jar)
        onProgress("Mengirim file server ke HP Game...", 0.45f)
        when (val pushResult = serverLauncher.prepareAndPushJar(jarFile)) {
            is AppResult.Success -> { /* ok */ }
            is AppResult.Error -> return@withContext pushResult
        }

        // 3. Start server process on HP 1
        onProgress("Menjalankan server di HP Game...", 0.65f)
        serverLauncher.startServer(config) { reason ->
            onServerDied(reason)
        }

        // Allow server a brief moment to initialize the abstract socket
        delay(300)

        // 4. Create and connect StreamSocket
        onProgress("Membuka stream video H.264...", 0.85f)
        val streamSocket = StreamSocket(
            adbClient = adbClient,
            onNalUnit = { nalUnit ->
                videoDecoder.feedNalUnit(nalUnit)
            },
            onError = { reason ->
                onStreamError(reason)
            }
        )

        when (val streamResult = streamSocket.connectAndStream()) {
            is AppResult.Success -> {
                Logger.i("Mirror stream pipeline successfully initiated")
                onProgress("Mirror stream siap!", 1.0f)
                AppResult.Success(streamSocket)
            }
            is AppResult.Error -> {
                streamSocket.close()
                serverLauncher.stopServer()
                streamResult
            }
        }
    }
}

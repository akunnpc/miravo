package com.mamang.mirrorlive.domain.usecase

import com.flyfishxu.kadb.Kadb
import com.mamang.mirrorlive.core.AppResult
import com.mamang.mirrorlive.data.adb.AdbClient
import com.mamang.mirrorlive.data.settings.MirrorPreferences

class ConnectDeviceUseCase(
    private val adbClient: AdbClient,
    private val preferences: MirrorPreferences
) {
    suspend operator fun invoke(host: String, port: Int): AppResult<Kadb> {
        val result = adbClient.connect(host, port)
        if (result is AppResult.Success) {
            preferences.saveLastConnection(host, port)
            preferences.setPaired(true)
        }
        return result
    }
}

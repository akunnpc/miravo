package com.mamang.mirrorlive.core

import android.content.Context
import com.mamang.mirrorlive.data.adb.AdbClient
import com.mamang.mirrorlive.data.adb.AdbDiscovery
import com.mamang.mirrorlive.data.adb.AdbKeyStore
import com.mamang.mirrorlive.data.server.ServerJarProvider
import com.mamang.mirrorlive.data.server.ServerLauncher
import com.mamang.mirrorlive.data.settings.MirrorPreferences
import com.mamang.mirrorlive.domain.usecase.ConnectDeviceUseCase
import com.mamang.mirrorlive.domain.usecase.DiscoverDevicesUseCase
import com.mamang.mirrorlive.domain.usecase.PairDeviceUseCase
import com.mamang.mirrorlive.domain.usecase.StartMirrorUseCase
import com.mamang.mirrorlive.domain.usecase.StopMirrorUseCase

class AppContainer(val context: Context) {

    init {
        AdbKeyStore.initialize(context)
    }

    val preferences = MirrorPreferences(context)
    val adbClient = AdbClient()
    val adbDiscovery = AdbDiscovery(context)
    val serverJarProvider = ServerJarProvider(context)
    val serverLauncher = ServerLauncher(adbClient)

    val pairDeviceUseCase = PairDeviceUseCase(adbClient, preferences)
    val discoverDevicesUseCase = DiscoverDevicesUseCase(adbDiscovery)
    val connectDeviceUseCase = ConnectDeviceUseCase(adbClient, preferences)
    val startMirrorUseCase = StartMirrorUseCase(adbClient, serverJarProvider, serverLauncher)
    val stopMirrorUseCase = StopMirrorUseCase(serverLauncher)

    companion object {
        @Volatile
        private var instance: AppContainer? = null

        fun getInstance(context: Context): AppContainer {
            return instance ?: synchronized(this) {
                instance ?: AppContainer(context.applicationContext).also { instance = it }
            }
        }
    }
}

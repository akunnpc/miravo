package com.mamang.mirrorlive.ui.client

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mamang.mirrorlive.core.AppContainer
import com.mamang.mirrorlive.core.AppResult
import com.mamang.mirrorlive.core.Logger
import com.mamang.mirrorlive.data.adb.QrPairingPayload
import com.mamang.mirrorlive.domain.model.ConnectionState
import com.mamang.mirrorlive.domain.model.DiscoveredDevice
import com.mamang.mirrorlive.domain.model.MirrorConfig
import com.mamang.mirrorlive.domain.model.MirrorError
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class Hp2ViewModel(application: Application) : AndroidViewModel(application) {

    private val container = AppContainer.getInstance(application)

    private val _currentStep = MutableStateFlow(1)
    val currentStep: StateFlow<Int> = _currentStep.asStateFlow()

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Idle)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _qrPayload = MutableStateFlow<QrPairingPayload?>(null)
    val qrPayload: StateFlow<QrPairingPayload?> = _qrPayload.asStateFlow()

    private val _qrBitmap = MutableStateFlow<Bitmap?>(null)
    val qrBitmap: StateFlow<Bitmap?> = _qrBitmap.asStateFlow()

    val isAlreadyPaired: StateFlow<Boolean> = container.preferences.isPairedFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val lastHost: StateFlow<String> = container.preferences.lastHostFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, "")

    val lastPort: StateFlow<Int> = container.preferences.lastPortFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    val mirrorConfig: StateFlow<MirrorConfig> = container.preferences.mirrorConfigFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, MirrorConfig())

    val connectDevices: StateFlow<List<DiscoveredDevice>> = container.discoverDevicesUseCase.connectDevices
    val isSearchingMdns: StateFlow<Boolean> = container.discoverDevicesUseCase.isSearching
    val hasMdnsTimedOut: StateFlow<Boolean> = container.discoverDevicesUseCase.hasTimedOut

    private var autoPairObserverJob: Job? = null

    init {
        generateNewQr()
        viewModelScope.launch {
            isAlreadyPaired.collect { paired ->
                if (paired && _currentStep.value == 1) {
                    // Skip to step 2 if already paired
                    _currentStep.value = 2
                    startDeviceDiscovery()
                }
            }
        }
    }

    fun generateNewQr() {
        val payload = QrPairingPayload.generate()
        _qrPayload.value = payload
        _connectionState.value = ConnectionState.WaitingQrScan(
            serviceName = payload.serviceName,
            password = payload.password,
            qrPayloadString = payload.rawString
        )

        viewModelScope.launch {
            try {
                val bitmap = QrPairingPayload.generateQrBitmap(payload.rawString)
                _qrBitmap.value = bitmap
            } catch (e: Exception) {
                Logger.e("Failed to generate QR bitmap", e)
            }
        }

        // Start mDNS listener to auto-pair when HP 1 scans QR
        listenForMdnsPairing(payload.password)
    }

    private fun listenForMdnsPairing(password: String) {
        autoPairObserverJob?.cancel()
        container.discoverDevicesUseCase.startDiscovery()

        autoPairObserverJob = viewModelScope.launch {
            container.discoverDevicesUseCase.pairDevices.collect { pairList ->
                if (pairList.isNotEmpty() && _currentStep.value == 1) {
                    val endpoint = pairList.first()
                    Logger.i("Detected pairing endpoint from mDNS: ${endpoint.host}:${endpoint.port}, auto-pairing...")
                    pairWithCode(endpoint.host, endpoint.port, password)
                }
            }
        }
    }

    fun pairWithCode(host: String, port: Int, code: String) {
        if (host.isBlank() || port <= 0 || code.isBlank()) {
            _connectionState.value = ConnectionState.Error(
                MirrorError.PairingFailed("IP, port, dan kode pairing harus diisi.")
            )
            return
        }

        _connectionState.value = ConnectionState.PairingInProgress(host, port)
        viewModelScope.launch {
            when (val result = container.pairDeviceUseCase(host, port, code)) {
                is AppResult.Success -> {
                    _connectionState.value = ConnectionState.PairingSuccess(host)
                    autoPairObserverJob?.cancel()
                    _currentStep.value = 2
                    startDeviceDiscovery()
                }
                is AppResult.Error -> {
                    _connectionState.value = ConnectionState.Error(
                        MirrorError.PairingFailed(result.message)
                    )
                }
            }
        }
    }

    fun startDeviceDiscovery() {
        _connectionState.value = ConnectionState.SearchingDevice()
        container.discoverDevicesUseCase.startDiscovery(timeoutMs = 30_000L)
    }

    fun connectToDevice(host: String, port: Int, deviceName: String = "HP Game") {
        if (host.isBlank() || port <= 0) {
            _connectionState.value = ConnectionState.Error(
                MirrorError.ConnectionRefused("IP dan port koneksi tidak boleh kosong.")
            )
            return
        }

        _connectionState.value = ConnectionState.PreparingServer("Menghubungkan ke $host:$port...")
        viewModelScope.launch {
            when (val result = container.connectDeviceUseCase(host, port)) {
                is AppResult.Success -> {
                    _connectionState.value = ConnectionState.Connected(deviceName, host, port)
                    _currentStep.value = 3
                }
                is AppResult.Error -> {
                    _connectionState.value = ConnectionState.Error(
                        MirrorError.ConnectionRefused(result.message)
                    )
                }
            }
        }
    }

    fun goToStep(step: Int) {
        _currentStep.value = step
        if (step == 1) {
            generateNewQr()
        } else if (step == 2) {
            startDeviceDiscovery()
        }
    }

    fun retryCurrentAction() {
        when (_currentStep.value) {
            1 -> generateNewQr()
            2 -> startDeviceDiscovery()
            3 -> {
                val lastH = lastHost.value
                val lastP = lastPort.value
                if (lastH.isNotBlank() && lastP > 0) {
                    connectToDevice(lastH, lastP)
                } else {
                    _currentStep.value = 2
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        autoPairObserverJob?.cancel()
        container.discoverDevicesUseCase.stopDiscovery()
    }
}

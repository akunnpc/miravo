package com.mamang.mirrorlive.media

import android.media.MediaCodec
import android.media.MediaCodec.BufferInfo
import android.media.MediaFormat
import android.view.Surface
import com.mamang.mirrorlive.core.Logger
import com.mamang.mirrorlive.data.stream.NalUnit
import com.mamang.mirrorlive.data.stream.SpsParser
import com.mamang.mirrorlive.data.stream.VideoDimensions
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

class VideoDecoder(
    private val onDimensionsChanged: (width: Int, height: Int) -> Unit,
    private val onError: (Throwable) -> Unit
) {
    private var codec: MediaCodec? = null
    private var currentSurface: Surface? = null
    private val bufferInfo = BufferInfo()

    private var currentWidth = 0
    private var currentHeight = 0
    private var cachedSps: ByteArray? = null
    private var cachedPps: ByteArray? = null
    private val isConfigured = AtomicBoolean(false)
    private val isRunning = AtomicBoolean(false)

    @Synchronized
    fun setSurface(surface: Surface) {
        currentSurface = surface
        if (cachedSps != null && !isConfigured.get()) {
            initCodecInternal()
        }
    }

    @Synchronized
    fun feedNalUnit(nalUnit: NalUnit) {
        try {
            when (nalUnit.type) {
                7 -> { // SPS
                    val spsChanged = cachedSps == null || !cachedSps.contentEquals(nalUnit.data)
                    cachedSps = nalUnit.data

                    val parsedDim = SpsParser.parseDimensions(nalUnit.data)
                    if (parsedDim != null) {
                        if (parsedDim.width != currentWidth || parsedDim.height != currentHeight) {
                            Logger.i("SPS dimension changed: ${parsedDim.width}x${parsedDim.height} (was ${currentWidth}x${currentHeight})")
                            currentWidth = parsedDim.width
                            currentHeight = parsedDim.height
                            onDimensionsChanged(currentWidth, currentHeight)
                            if (isConfigured.get()) {
                                // Reconfigure decoder on rotation/dimension change
                                reconfigureCodec()
                                return
                            }
                        }
                    }

                    if (!isConfigured.get() && currentSurface != null) {
                        initCodecInternal()
                    }
                }
                8 -> { // PPS
                    cachedPps = nalUnit.data
                    if (!isConfigured.get() && cachedSps != null && currentSurface != null) {
                        initCodecInternal()
                    }
                }
                else -> {
                    // Slices (IDR or non-IDR)
                    if (!isConfigured.get()) {
                        // Cannot decode frame without SPS/PPS configuration
                        return
                    }
                    sendBufferToCodec(nalUnit.data, nalUnit.isKeyFrame)
                    drainOutputBuffers()
                }
            }
        } catch (e: Exception) {
            Logger.e("Error feeding NAL unit to decoder", e)
            onError(e)
        }
    }

    private fun initCodecInternal() {
        val surface = currentSurface ?: return
        val sps = cachedSps ?: return

        try {
            releaseCodec()

            val width = if (currentWidth > 0) currentWidth else 1280
            val height = if (currentHeight > 0) currentHeight else 720

            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                setByteBuffer("csd-0", ByteBuffer.wrap(sps))
                cachedPps?.let { pps ->
                    setByteBuffer("csd-1", ByteBuffer.wrap(pps))
                }
                // Low latency mode (API 30+)
                setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
                setInteger(MediaFormat.KEY_PRIORITY, 0)
            }

            val newCodec = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            newCodec.configure(format, surface, null, 0)
            newCodec.start()

            codec = newCodec
            isConfigured.set(true)
            isRunning.set(true)
            Logger.i("MediaCodec initialized for AVC ${width}x${height} with low-latency mode")
        } catch (e: Exception) {
            Logger.e("Failed to initialize MediaCodec", e)
            isConfigured.set(false)
            onError(e)
        }
    }

    private fun reconfigureCodec() {
        Logger.i("Reconfiguring MediaCodec for new dimensions: ${currentWidth}x${currentHeight}")
        initCodecInternal()
    }

    private fun sendBufferToCodec(data: ByteArray, isKeyFrame: Boolean) {
        val currentCodec = codec ?: return
        val inputIndex = currentCodec.dequeueInputBuffer(10_000L) // 10ms timeout
        if (inputIndex >= 0) {
            val inputBuffer = currentCodec.getInputBuffer(inputIndex) ?: return
            inputBuffer.clear()
            inputBuffer.put(data)

            val flags = if (isKeyFrame) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
            val pts = System.nanoTime() / 1000L
            currentCodec.queueInputBuffer(inputIndex, 0, data.size, pts, flags)
        } else {
            Logger.w("MediaCodec input buffer not available, dropping frame to maintain low latency")
        }
    }

    private fun drainOutputBuffers() {
        val currentCodec = codec ?: return
        while (isRunning.get()) {
            val outputIndex = currentCodec.dequeueOutputBuffer(bufferInfo, 0L)
            when {
                outputIndex >= 0 -> {
                    // Render frame to surface immediately
                    currentCodec.releaseOutputBuffer(outputIndex, true)
                }
                outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    val newFormat = currentCodec.outputFormat
                    val width = newFormat.getInteger(MediaFormat.KEY_WIDTH)
                    val height = newFormat.getInteger(MediaFormat.KEY_HEIGHT)
                    val cropLeft = if (newFormat.containsKey("crop-left")) newFormat.getInteger("crop-left") else 0
                    val cropRight = if (newFormat.containsKey("crop-right")) newFormat.getInteger("crop-right") else width - 1
                    val cropTop = if (newFormat.containsKey("crop-top")) newFormat.getInteger("crop-top") else 0
                    val cropBottom = if (newFormat.containsKey("crop-bottom")) newFormat.getInteger("crop-bottom") else height - 1

                    val actualW = cropRight - cropLeft + 1
                    val actualH = cropBottom - cropTop + 1
                    Logger.i("MediaCodec INFO_OUTPUT_FORMAT_CHANGED: ${actualW}x${actualH}")
                    if (actualW > 0 && actualH > 0 && (actualW != currentWidth || actualH != currentHeight)) {
                        currentWidth = actualW
                        currentHeight = actualH
                        onDimensionsChanged(actualW, actualH)
                    }
                }
                outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    break
                }
            }
        }
    }

    @Synchronized
    fun release() {
        isRunning.set(false)
        isConfigured.set(false)
        releaseCodec()
        cachedSps = null
        cachedPps = null
        currentSurface = null
        currentWidth = 0
        currentHeight = 0
    }

    private fun releaseCodec() {
        try {
            codec?.stop()
        } catch (_: Exception) {}
        try {
            codec?.release()
        } catch (_: Exception) {}
        codec = null
    }
}

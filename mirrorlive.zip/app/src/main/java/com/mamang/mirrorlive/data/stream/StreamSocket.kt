package com.mamang.mirrorlive.data.stream

import com.flyfishxu.kadb.stream.AdbStream
import com.mamang.mirrorlive.core.AppResult
import com.mamang.mirrorlive.core.Constants
import com.mamang.mirrorlive.core.Logger
import com.mamang.mirrorlive.data.adb.AdbClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class StreamSocket(
    private val adbClient: AdbClient,
    private val onNalUnit: (NalUnit) -> Unit,
    private val onError: (String) -> Unit
) {
    private var activeStream: AdbStream? = null
    private var streamJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private val annexBParser = AnnexBParser(onNalUnit)

    suspend fun connectAndStream(
        retries: Int = Constants.MAX_CONNECT_RETRIES,
        delayMs: Long = Constants.RETRY_DELAY_MS
    ): AppResult<Unit> = withContext(Dispatchers.IO) {
        close()

        var stream: AdbStream? = null
        var lastError: String = "Server belum siap"

        for (attempt in 1..retries) {
            if (!coroutineContext.isActive) {
                return@withContext AppResult.Error(IllegalStateException("Streaming dibatalkan"))
            }

            Logger.d("Attempting to connect to ${Constants.ADB_LOCALABSTRACT_DEST} (attempt $attempt/$retries)")
            when (val result = adbClient.openStream(Constants.ADB_LOCALABSTRACT_DEST)) {
                is AppResult.Success -> {
                    val candidateStream = result.data
                    try {
                        // Quick probe: try to see if source is open and not instantly EOF
                        // Because raw_stream has no dummy byte, server writes first NAL (SPS/PPS) upon connection
                        if (!candidateStream.source.exhausted()) {
                            stream = candidateStream
                            Logger.i("Successfully connected to ${Constants.ADB_LOCALABSTRACT_DEST} on attempt $attempt")
                            break
                        } else {
                            Logger.w("Stream connected but source is exhausted (EOF) on attempt $attempt")
                            candidateStream.close()
                            lastError = "Koneksi stream menerima EOF (server belum siap)"
                        }
                    } catch (e: Exception) {
                        Logger.w("Probe read failed on attempt $attempt: ${e.message}")
                        try { candidateStream.close() } catch (_: Exception) {}
                        lastError = e.localizedMessage ?: "Stream gagal dibaca"
                    }
                }
                is AppResult.Error -> {
                    lastError = result.message
                    Logger.d("openStream failed on attempt $attempt: $lastError")
                }
            }

            delay(delayMs)
        }

        if (stream == null) {
            val failureMsg = "Gagal terhubung ke socket stream server scrcpy setelah $retries percobaan: $lastError"
            Logger.e(failureMsg)
            return@withContext AppResult.Error(IllegalStateException(failureMsg), failureMsg)
        }

        activeStream = stream
        startReadLoop(stream)
        AppResult.Success(Unit)
    }

    private fun startReadLoop(stream: AdbStream) {
        streamJob = scope.launch {
            val buffer = ByteArray(32 * 1024)
            try {
                Logger.i("Starting video read loop from ADB stream...")
                val source = stream.source
                while (isActive && !source.exhausted()) {
                    val bytesRead = source.read(buffer)
                    if (bytesRead == -1) {
                        Logger.w("Reached EOF in video stream")
                        break
                    }
                    if (bytesRead > 0) {
                        annexBParser.parse(buffer, 0, bytesRead)
                    }
                }
                annexBParser.flush()
                if (isActive) {
                    Logger.w("Video stream ended (EOF or connection closed)")
                    onError("Stream video dari HP Game terputus (EOF).")
                }
            } catch (e: Exception) {
                Logger.e("Exception in video read loop", e)
                if (isActive) {
                    onError("Terjadi kesalahan saat membaca stream video: ${e.localizedMessage}")
                }
            } finally {
                close()
            }
        }
    }

    fun close() {
        streamJob?.cancel()
        streamJob = null
        try {
            activeStream?.close()
        } catch (e: Exception) {
            Logger.w("Error closing active AdbStream", e)
        } finally {
            activeStream = null
        }
    }
}

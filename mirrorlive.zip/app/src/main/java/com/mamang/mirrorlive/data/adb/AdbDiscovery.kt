package com.mamang.mirrorlive.data.adb

import android.content.Context
import com.flyfishxu.kadb.mdns.KadbMdnsAndroid
import com.flyfishxu.kadb.mdns.MdnsDiscoveryState
import com.mamang.mirrorlive.core.Logger
import com.mamang.mirrorlive.domain.model.DiscoveredDevice
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AdbDiscovery(private val context: Context) {

    private var mdnsInstance: KadbMdnsAndroid? = null
    private var observerJob: Job? = null
    private var timeoutJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    private val _connectDevices = MutableStateFlow<List<DiscoveredDevice>>(emptyList())
    val connectDevices: StateFlow<List<DiscoveredDevice>> = _connectDevices.asStateFlow()

    private val _pairDevices = MutableStateFlow<List<DiscoveredDevice>>(emptyList())
    val pairDevices: StateFlow<List<DiscoveredDevice>> = _pairDevices.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _hasTimedOut = MutableStateFlow(false)
    val hasTimedOut: StateFlow<Boolean> = _hasTimedOut.asStateFlow()

    fun startDiscovery(timeoutMs: Long = 30_000L) {
        stopDiscovery()
        _hasTimedOut.value = false
        _isSearching.value = true

        try {
            val mdns = KadbMdnsAndroid(context)
            mdnsInstance = mdns
            mdns.start()
            Logger.i("AdbDiscovery mDNS service started")

            observerJob = scope.launch {
                mdns.state.collect { discoveryState: MdnsDiscoveryState ->
                    val connectList = discoveryState.connectDevices.map { ep ->
                        DiscoveredDevice(
                            id = "${ep.host}:${ep.port}",
                            name = ep.name.ifBlank { "HP Game (${ep.host})" },
                            host = ep.host,
                            port = ep.port,
                            isPairingService = false
                        )
                    }
                    val pairList = discoveryState.pairDevices.map { ep ->
                        DiscoveredDevice(
                            id = "${ep.host}:${ep.port}",
                            name = ep.name.ifBlank { "Pairing HP Game" },
                            host = ep.host,
                            port = ep.port,
                            isPairingService = true
                        )
                    }

                    _connectDevices.value = connectList
                    _pairDevices.value = pairList
                }
            }

            timeoutJob = scope.launch {
                delay(timeoutMs)
                if (_connectDevices.value.isEmpty()) {
                    _hasTimedOut.value = true
                    Logger.w("AdbDiscovery timed out without finding connect devices")
                }
                _isSearching.value = false
            }
        } catch (e: Exception) {
            Logger.e("Failed to start mDNS discovery", e)
            _isSearching.value = false
        }
    }

    fun stopDiscovery() {
        observerJob?.cancel()
        observerJob = null
        timeoutJob?.cancel()
        timeoutJob = null

        try {
            mdnsInstance?.stop()
            mdnsInstance?.close()
        } catch (e: Exception) {
            Logger.w("Error closing mDNS instance", e)
        }
        mdnsInstance = null
        _isSearching.value = false
    }
}

package com.mamang.mirrorlive

import android.app.Application
import androidx.test.core.app.ApplicationProvider
import com.mamang.mirrorlive.ui.host.Hp1ViewModel
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class Hp1ViewModelTest {

    @Test
    fun testHp1ViewModelCreationDoesNotCrash() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val viewModel = Hp1ViewModel(app)
        assertNotNull(viewModel.state.value)
    }
}

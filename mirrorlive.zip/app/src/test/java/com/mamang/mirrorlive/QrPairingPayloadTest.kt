package com.mamang.mirrorlive

import com.mamang.mirrorlive.data.adb.QrPairingPayload
import com.mamang.mirrorlive.data.server.ServerOptions
import com.mamang.mirrorlive.domain.model.MirrorConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class QrPairingPayloadTest {

    @Test
    fun testQrPayloadFormat() {
        val payload = QrPairingPayload.generate()
        assertTrue(payload.serviceName.startsWith("mirrorlive_"))
        assertEquals(6, payload.password.length)
        assertTrue(payload.rawString.startsWith("WIFI:T:ADB;S:${payload.serviceName};P:${payload.password};;"))
    }

    @Test
    fun testServerCommandConstruction() {
        val config = MirrorConfig(maxSize = 1080, bitRate = 8000000, maxFps = 60)
        val cmd = ServerOptions.buildServerCommand(config)

        assertTrue(cmd.contains("com.genymobile.scrcpy.Server 4.0"))
        assertTrue(cmd.contains("tunnel_forward=true"))
        assertTrue(cmd.contains("raw_stream=true"))
        assertTrue(cmd.contains("max_size=1080"))
        assertTrue(cmd.contains("video_bit_rate=8000000"))
        assertTrue(cmd.contains("max_fps=60"))
    }
}

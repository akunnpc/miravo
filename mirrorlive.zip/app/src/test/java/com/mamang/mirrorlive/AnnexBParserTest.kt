package com.mamang.mirrorlive

import com.mamang.mirrorlive.data.stream.AnnexBParser
import com.mamang.mirrorlive.data.stream.NalUnit
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AnnexBParserTest {

    @Test
    fun testSplitsNalUnitsCorrectly() {
        val capturedNals = mutableListOf<NalUnit>()
        val parser = AnnexBParser { nal -> capturedNals.add(nal) }

        // Construct 2 NAL units:
        // NAL 1: 00 00 00 01 67 (SPS, type 7) + 5 bytes payload
        // NAL 2: 00 00 01 68 (PPS, type 8) + 4 bytes payload
        // NAL 3: 00 00 00 01 65 (IDR, type 5) + 10 bytes payload
        val streamData = byteArrayOf(
            0, 0, 0, 1, 0x67.toByte(), 10, 20, 30, 40, 50,
            0, 0, 1, 0x68.toByte(), 1, 2, 3, 4,
            0, 0, 0, 1, 0x65.toByte(), 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,
            0, 0, 0, 1, 0x41.toByte() // next start code to flush NAL 3
        )

        parser.parse(streamData)
        parser.flush()

        assertTrue(capturedNals.size >= 3)
        assertEquals(7, capturedNals[0].type)
        assertTrue(capturedNals[0].isKeyFrame)
        assertEquals(8, capturedNals[1].type)
        assertEquals(5, capturedNals[2].type)
        assertTrue(capturedNals[2].isKeyFrame)
    }
}

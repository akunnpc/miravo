package com.mamang.mirrorlive.data.stream

data class NalUnit(
    val data: ByteArray,
    val type: Int,
    val isKeyFrame: Boolean
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as NalUnit
        return data.contentEquals(other.data) && type == other.type
    }

    override fun hashCode(): Int {
        var result = data.contentHashCode()
        result = 31 * result + type
        return result
    }
}

class AnnexBParser(
    private val onNalUnit: (NalUnit) -> Unit
) {
    private var buffer = ByteArray(256 * 1024)
    private var bufferSize = 0

    fun parse(bytes: ByteArray, offset: Int = 0, length: Int = bytes.size) {
        ensureCapacity(bufferSize + length)
        System.arraycopy(bytes, offset, buffer, bufferSize, length)
        bufferSize += length

        var searchStart = 0
        while (true) {
            val sc1 = findStartCode(buffer, searchStart, bufferSize) ?: break
            val sc2 = findStartCode(buffer, sc1.endIndex, bufferSize)

            if (sc2 == null) {
                // We have the beginning of a NAL unit at sc1.startIndex, but not the end yet.
                // Shift remaining data to start of buffer and wait for more bytes.
                if (sc1.startIndex > 0) {
                    val remaining = bufferSize - sc1.startIndex
                    System.arraycopy(buffer, sc1.startIndex, buffer, 0, remaining)
                    bufferSize = remaining
                }
                break
            }

            // A complete NAL unit is located between sc1.startIndex and sc2.startIndex
            val nalLength = sc2.startIndex - sc1.startIndex
            if (nalLength > 0) {
                val nalData = ByteArray(nalLength)
                System.arraycopy(buffer, sc1.startIndex, nalData, 0, nalLength)
                emitNalUnit(nalData)
            }

            searchStart = sc2.startIndex
        }
    }

    private fun emitNalUnit(nalData: ByteArray) {
        if (nalData.size < 4) return

        // Skip start code prefix (00 00 01 or 00 00 00 01) to locate NAL header
        var headerIndex = 0
        if (nalData.size >= 4 && nalData[0] == 0.toByte() && nalData[1] == 0.toByte() && nalData[2] == 0.toByte() && nalData[3] == 1.toByte()) {
            headerIndex = 4
        } else if (nalData.size >= 3 && nalData[0] == 0.toByte() && nalData[1] == 0.toByte() && nalData[2] == 1.toByte()) {
            headerIndex = 3
        }

        if (headerIndex >= nalData.size) return

        val headerByte = nalData[headerIndex].toInt() and 0xFF
        val nalType = headerByte and 0x1F
        val isKeyFrame = nalType == 5 || nalType == 7 // IDR or SPS

        onNalUnit(
            NalUnit(
                data = nalData,
                type = nalType,
                isKeyFrame = isKeyFrame
            )
        )
    }

    fun flush() {
        if (bufferSize > 0) {
            val sc = findStartCode(buffer, 0, bufferSize)
            if (sc != null) {
                val nalLength = bufferSize - sc.startIndex
                if (nalLength > 0) {
                    val nalData = ByteArray(nalLength)
                    System.arraycopy(buffer, sc.startIndex, nalData, 0, nalLength)
                    emitNalUnit(nalData)
                }
            }
            bufferSize = 0
        }
    }

    private data class StartCode(val startIndex: Int, val endIndex: Int)

    private fun findStartCode(data: ByteArray, start: Int, end: Int): StartCode? {
        var i = start
        while (i <= end - 3) {
            if (data[i] == 0.toByte() && data[i + 1] == 0.toByte() && data[i + 2] == 1.toByte()) {
                val scStart = if (i > start && data[i - 1] == 0.toByte()) i - 1 else i
                return StartCode(scStart, i + 3)
            }
            i++
        }
        return null
    }

    private fun ensureCapacity(required: Int) {
        if (required > buffer.size) {
            var newCap = buffer.size * 2
            while (newCap < required) {
                newCap *= 2
            }
            val newBuf = ByteArray(newCap)
            System.arraycopy(buffer, 0, newBuf, 0, bufferSize)
            buffer = newBuf
        }
    }
}

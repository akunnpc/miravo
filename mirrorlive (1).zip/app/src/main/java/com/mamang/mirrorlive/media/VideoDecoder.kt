package com.mamang.mirrorlive.media

import android.media.MediaCodec
import android.media.MediaCodec.BufferInfo
import android.media.MediaFormat
import android.view.Surface
import com.mamang.mirrorlive.core.Logger
import com.mamang.mirrorlive.data.stream.NalUnit
import com.mamang.mirrorlive.data.stream.SpsParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

class VideoDecoder(
    private val onDimensionsChanged: (width: Int, height: Int) -> Unit,
    private val onError: (Throwable) -> Unit
) {
    private var codec: MediaCodec? = null
    private var currentSurface: Surface? = null
    private val bufferInfo = BufferInfo()

    private var currentWidth = 0
    private var currentHeight = 0
    private var cachedSps: ByteArray? = null
    private var cachedPps: ByteArray? = null
    private val isConfigured = AtomicBoolean(false)
    private val isRunning = AtomicBoolean(false)

    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private var drainJob: Job? = null

    @Synchronized
    fun setSurface(surface: Surface) {
        if (!surface.isValid) {
            Logger.w("Provided surface is not valid")
            return
        }
        val prevSurface = currentSurface
        currentSurface = surface

        if (codec != null && isConfigured.get()) {
            try {
                Logger.i("Switching MediaCodec output surface dynamically")
                codec?.setOutputSurface(surface)
            } catch (e: Exception) {
                Logger.w("setOutputSurface failed, reconfiguring codec", e)
                initCodecInternal()
            }
        } else if (cachedSps != null && cachedPps != null && !isConfigured.get()) {
            initCodecInternal()
        }
    }

    @Synchronized
    fun feedNalUnit(nalUnit: NalUnit) {
        try {
            when (nalUnit.type) {
                7 -> { // SPS
                    val spsChanged = cachedSps == null || !cachedSps.contentEquals(nalUnit.data)
                    cachedSps = nalUnit.data

                    val parsedDim = SpsParser.parseDimensions(nalUnit.data)
                    if (parsedDim != null) {
                        if (parsedDim.width != currentWidth || parsedDim.height != currentHeight) {
                            Logger.i("SPS dimension changed: ${parsedDim.width}x${parsedDim.height} (was ${currentWidth}x${currentHeight})")
                            currentWidth = parsedDim.width
                            currentHeight = parsedDim.height
                            onDimensionsChanged(currentWidth, currentHeight)
                            if (isConfigured.get() && cachedPps != null) {
                                initCodecInternal()
                                return
                            }
                        }
                    }

                    // Only configure when BOTH SPS and PPS are available
                    if (!isConfigured.get() && cachedPps != null && currentSurface != null) {
                        initCodecInternal()
                    }
                }
                8 -> { // PPS
                    cachedPps = nalUnit.data
                    if (!isConfigured.get() && cachedSps != null && currentSurface != null) {
                        initCodecInternal()
                    } else if (isConfigured.get()) {
                        // Queue in-band PPS with CODEC_CONFIG flag
                        sendBufferToCodec(nalUnit.data, MediaCodec.BUFFER_FLAG_CODEC_CONFIG)
                    }
                }
                else -> { // Video Slices (IDR or non-IDR)
                    if (!isConfigured.get()) {
                        // Wait for SPS and PPS before feeding video slices
                        return
                    }
                    val flags = if (nalUnit.isKeyFrame) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    sendBufferToCodec(nalUnit.data, flags)
                }
            }
        } catch (e: Exception) {
            Logger.e("Error feeding NAL unit to decoder", e)
            onError(e)
        }
    }

    @Synchronized
    private fun initCodecInternal() {
        val surface = currentSurface
        if (surface == null || !surface.isValid) {
            Logger.w("Cannot initialize MediaCodec: surface is null or invalid")
            return
        }
        val sps = cachedSps
        val pps = cachedPps
        if (sps == null || pps == null) {
            Logger.w("Cannot initialize MediaCodec: waiting for both SPS and PPS")
            return
        }

        try {
            releaseCodec()

            val width = if (currentWidth > 0) currentWidth else 1280
            val height = if (currentHeight > 0) currentHeight else 720

            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                setByteBuffer("csd-0", ByteBuffer.wrap(sps))
                setByteBuffer("csd-1", ByteBuffer.wrap(pps))
                setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
                setInteger(MediaFormat.KEY_PRIORITY, 0)
            }

            val newCodec = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            newCodec.configure(format, surface, null, 0)
            newCodec.start()

            codec = newCodec
            isConfigured.set(true)
            isRunning.set(true)

            // Start dedicated output draining loop
            startDrainLoop(newCodec)

            Logger.i("MediaCodec initialized for AVC ${width}x${height} with low-latency mode and active drain loop")
        } catch (e: Exception) {
            Logger.e("Failed to initialize MediaCodec", e)
            isConfigured.set(false)
            onError(e)
        }
    }

    private fun startDrainLoop(activeCodec: MediaCodec) {
        drainJob?.cancel()
        drainJob = scope.launch {
            Logger.d("Starting MediaCodec output buffer drain loop")
            while (isRunning.get() && isActive) {
                try {
                    val outputIndex = activeCodec.dequeueOutputBuffer(bufferInfo, 10_000L) // 10ms wait
                    when {
                        outputIndex >= 0 -> {
                            // Immediately render decoded frame to surface!
                            activeCodec.releaseOutputBuffer(outputIndex, true)
                        }
                        outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val newFormat = activeCodec.outputFormat
                            val width = newFormat.getInteger(MediaFormat.KEY_WIDTH)
                            val height = newFormat.getInteger(MediaFormat.KEY_HEIGHT)
                            val cropLeft = if (newFormat.containsKey("crop-left")) newFormat.getInteger("crop-left") else 0
                            val cropRight = if (newFormat.containsKey("crop-right")) newFormat.getInteger("crop-right") else width - 1
                            val cropTop = if (newFormat.containsKey("crop-top")) newFormat.getInteger("crop-top") else 0
                            val cropBottom = if (newFormat.containsKey("crop-bottom")) newFormat.getInteger("crop-bottom") else height - 1

                            val actualW = cropRight - cropLeft + 1
                            val actualH = cropBottom - cropTop + 1
                            Logger.i("MediaCodec INFO_OUTPUT_FORMAT_CHANGED: ${actualW}x${actualH}")
                            if (actualW > 0 && actualH > 0 && (actualW != currentWidth || actualH != currentHeight)) {
                                currentWidth = actualW
                                currentHeight = actualH
                                onDimensionsChanged(actualW, actualH)
                            }
                        }
                        outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            // No frame ready yet, continue loop
                        }
                    }
                } catch (e: Exception) {
                    if (isRunning.get() && isActive) {
                        Logger.w("Drain loop exception: ${e.message}")
                    }
                    break
                }
            }
        }
    }

    private fun sendBufferToCodec(data: ByteArray, flags: Int) {
        val currentCodec = codec ?: return
        val inputIndex = try {
            currentCodec.dequeueInputBuffer(10_000L) // 10ms timeout
        } catch (e: Exception) {
            -1
        }

        if (inputIndex >= 0) {
            val inputBuffer = currentCodec.getInputBuffer(inputIndex) ?: return
            inputBuffer.clear()
            inputBuffer.put(data)

            val pts = System.nanoTime() / 1000L
            currentCodec.queueInputBuffer(inputIndex, 0, data.size, pts, flags)
        } else {
            Logger.w("MediaCodec input buffer not available (dropped frame for low latency)")
        }
    }

    @Synchronized
    fun release() {
        isRunning.set(false)
        isConfigured.set(false)
        drainJob?.cancel()
        drainJob = null
        releaseCodec()
        cachedSps = null
        cachedPps = null
        currentSurface = null
        currentWidth = 0
        currentHeight = 0
    }

    private fun releaseCodec() {
        drainJob?.cancel()
        drainJob = null
        try {
            codec?.stop()
        } catch (_: Exception) {}
        try {
            codec?.release()
        } catch (_: Exception) {}
        codec = null
    }
}

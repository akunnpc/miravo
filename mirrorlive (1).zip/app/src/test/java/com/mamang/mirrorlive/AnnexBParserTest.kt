package com.mamang.mirrorlive

import com.mamang.mirrorlive.data.stream.AnnexBParser
import com.mamang.mirrorlive.data.stream.NalUnit
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AnnexBParserTest {

    @Test
    fun testSplitsNalUnitsCorrectly() {
        val capturedNals = mutableListOf<NalUnit>()
        val parser = AnnexBParser { nal -> capturedNals.add(nal) }

        // Construct 2 NAL units:
        // NAL 1: 00 00 00 01 67 (SPS, type 7) + 5 bytes payload
        // NAL 2: 00 00 01 68 (PPS, type 8) + 4 bytes payload
        // NAL 3: 00 00 00 01 65 (IDR, type 5) + 10 bytes payload
        val streamData = byteArrayOf(
            0, 0, 0, 1, 0x67.toByte(), 10, 20, 30, 40, 50,
            0, 0, 1, 0x68.toByte(), 1, 2, 3, 4,
            0, 0, 0, 1, 0x65.toByte(), 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,
            0, 0, 0, 1, 0x41.toByte() // next start code to flush NAL 3
        )

        parser.parse(streamData)
        parser.flush()

        assertTrue(capturedNals.size >= 3)
        assertEquals(7, capturedNals[0].type)
        assertTrue(capturedNals[0].isKeyFrame)
        assertEquals(10, capturedNals[0].data.size)

        assertEquals(8, capturedNals[1].type)
        assertEquals(8, capturedNals[1].data.size)

        assertEquals(5, capturedNals[2].type)
        assertTrue(capturedNals[2].isKeyFrame)
        assertEquals(15, capturedNals[2].data.size)
    }

    @Test
    fun testChunkedStreamDoesNotTruncate() {
        val capturedNals = mutableListOf<NalUnit>()
        val parser = AnnexBParser { nal -> capturedNals.add(nal) }

        val streamData = byteArrayOf(
            0, 0, 0, 1, 0x67.toByte(), 10, 20, 30,
            0, 0, 1, 0x68.toByte(), 40, 50,
            0, 0, 0, 1, 0x65.toByte(), 60, 70, 80,
            0, 0, 0, 1
        )

        // Feed in 3-byte chunks to test fragmented packets
        for (i in streamData.indices step 3) {
            val end = (i + 3).coerceAtMost(streamData.size)
            parser.parse(streamData, i, end - i)
        }
        parser.flush()

        assertEquals(3, capturedNals.size)
        assertEquals(8, capturedNals[0].data.size)
        assertEquals(6, capturedNals[1].data.size)
        assertEquals(8, capturedNals[2].data.size)
    }
}
